package com.autoclicker.autoswiper.save;

import android.content.SharedPreferences;
import android.util.Log;
import android.view.WindowManager.LayoutParams;
import com.autoclicker.autoswiper.FloatingViewService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SaveItem {
    private Map<String, Integer> delay_target = new HashMap();
    private ArrayList<Integer> px = new ArrayList();
    private ArrayList<Integer> py = new ArrayList();
    private ArrayList<Integer> swipe_target = new ArrayList();
    private int target_num;

    public Map<String, Integer> getDelay_target() {
        return this.delay_target;
    }

    public void setDelay_target(Map<String, Integer> map) {
        this.delay_target = map;
    }

    public SaveItem() {
        StringBuilder stringBuilder;
        if (FloatingViewService.mPointerView_auto == null) {
            FloatingViewService.mPointerView_auto = new HashMap();
        }
        setTarget_num(FloatingViewService.mPointerView_auto.size());
        setSwipe_target(FloatingViewService.swipe_target);
        int i = 1;
        for (int i2 = 1; i2 <= FloatingViewService.target_num; i2++) {
            Map map = FloatingViewService.mParams_auto;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("mParams_auto");
            stringBuilder2.append(String.valueOf(i2));
            int i3 = ((LayoutParams) map.get(stringBuilder2.toString())).x;
            Map map2 = FloatingViewService.mParams_auto;
            stringBuilder = new StringBuilder();
            stringBuilder.append("mParams_auto");
            stringBuilder.append(String.valueOf(i2));
            int i4 = ((LayoutParams) map2.get(stringBuilder.toString())).y;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(String.valueOf(i3));
            stringBuilder3.append(" | ");
            stringBuilder3.append(String.valueOf(i4));
            Log.d("px py", stringBuilder3.toString());
            this.px.add(Integer.valueOf(i3));
            this.py.add(Integer.valueOf(i4));
        }
        while (i <= FloatingViewService.target_num) {
            Map map3 = this.delay_target;
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("mPointer_Auto_Before");
            stringBuilder4.append(String.valueOf(i));
            String stringBuilder5 = stringBuilder4.toString();
            SharedPreferences sharedPreferences = FloatingViewService.settings;
            stringBuilder = new StringBuilder();
            stringBuilder.append("mPointer_Auto_Before");
            stringBuilder.append(String.valueOf(i));
            map3.put(stringBuilder5, Integer.valueOf(sharedPreferences.getInt(stringBuilder.toString(), 0)));
            map3 = this.delay_target;
            stringBuilder4 = new StringBuilder();
            stringBuilder4.append("mPointer_Auto_After");
            stringBuilder4.append(String.valueOf(i));
            stringBuilder5 = stringBuilder4.toString();
            sharedPreferences = FloatingViewService.settings;
            stringBuilder = new StringBuilder();
            stringBuilder.append("mPointer_Auto_After");
            stringBuilder.append(String.valueOf(i));
            map3.put(stringBuilder5, Integer.valueOf(sharedPreferences.getInt(stringBuilder.toString(), 0)));
            i++;
        }
        setPx(this.px);
        setPy(this.py);
    }

    public ArrayList getPx() {
        return this.px;
    }

    public void setPx(ArrayList<Integer> arrayList) {
        this.px = arrayList;
    }

    public ArrayList getPy() {
        return this.py;
    }

    public void setPy(ArrayList<Integer> arrayList) {
        this.py = arrayList;
    }

    public ArrayList getSwipe_target() {
        return this.swipe_target;
    }

    public void setSwipe_target(ArrayList<Integer> arrayList) {
        this.swipe_target = arrayList;
    }

    public int getTarget_num() {
        return this.target_num;
    }

    public void setTarget_num(int i) {
        this.target_num = i;
    }
}
