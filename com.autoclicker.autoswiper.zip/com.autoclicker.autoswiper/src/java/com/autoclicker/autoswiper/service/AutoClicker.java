package com.autoclicker.autoswiper.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.GestureResultCallback;
import android.accessibilityservice.GestureDescription.Builder;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed;

public final class AutoClicker extends AccessibilityService {
    public static AutoClicker instance;

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
    }

    public void onInterrupt() {
    }

    public static AutoClicker getAutoClickService() {
        return instance;
    }

    public static final void setAutoClickService(@Nullable AutoClicker autoClicker) {
        instance = autoClicker;
    }

    /* Access modifiers changed, original: protected */
    public void onServiceConnected() {
        super.onServiceConnected();
        setAutoClickService(this);
        Log.d("onServiceConnected : ", "Success");
    }

    public final void click(int i, int i2) {
        Path path = new Path();
        if (i < 0) {
            i = 0;
        }
        if (i > FloatingViewService.deviceWidth) {
            i = FloatingViewService.deviceWidth;
        }
        if (i2 < 0) {
            i2 = 0;
        }
        if (i2 > FloatingViewService.deviceHeight) {
            i2 = FloatingViewService.deviceHeight;
        }
        Log.d("auto click target_num", String.valueOf(FloatingViewService.target_rotation));
        try {
            Log.d("Before Target Num", String.valueOf(FloatingViewService.target_rotation));
            SharedPreferences sharedPreferences = FloatingViewService.settings;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("mPointer_Auto_Before");
            stringBuilder.append(String.valueOf(FloatingViewService.target_rotation));
            Thread.sleep((long) sharedPreferences.getInt(stringBuilder.toString(), 0));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        path.moveTo((float) i, (float) i2);
        dispatchGesture(new Builder().addStroke(new StrokeDescription(path, 0, 10)).build(), (GestureResultCallback) null, (Handler) null);
        try {
            Log.d("After Target Num", String.valueOf(FloatingViewService.target_rotation));
            SharedPreferences sharedPreferences2 = FloatingViewService.settings;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("mPointer_Auto_After");
            stringBuilder2.append(String.valueOf(FloatingViewService.target_rotation));
            Thread.sleep((long) sharedPreferences2.getInt(stringBuilder2.toString(), 0));
        } catch (InterruptedException e2) {
            e2.printStackTrace();
        }
    }

    public final void swipe(int i, int i2, int i3, int i4) {
        Path path = new Path();
        if (i < 0) {
            i = 0;
        }
        if (i > FloatingViewService.deviceWidth) {
            i = FloatingViewService.deviceWidth;
        }
        if (i2 < 0) {
            i2 = 0;
        }
        if (i2 > FloatingViewService.deviceHeight) {
            i2 = FloatingViewService.deviceHeight;
        }
        if (i3 < 0) {
            i3 = 0;
        }
        if (i3 > FloatingViewService.deviceWidth) {
            i3 = FloatingViewService.deviceWidth;
        }
        if (i4 < 0) {
            i4 = 0;
        }
        if (i4 > FloatingViewService.deviceHeight) {
            i4 = FloatingViewService.deviceHeight;
        }
        Log.d("auto click target_num", String.valueOf(FloatingViewService.target_rotation));
        try {
            Log.d("Before Target Num", String.valueOf(FloatingViewService.target_rotation));
            SharedPreferences sharedPreferences = FloatingViewService.settings;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("mPointer_Auto_Before");
            stringBuilder.append(String.valueOf(FloatingViewService.target_rotation));
            Thread.sleep((long) sharedPreferences.getInt(stringBuilder.toString(), 0));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        path.moveTo((float) i, (float) i2);
        path.lineTo((float) i3, (float) i4);
        dispatchGesture(new Builder().addStroke(new StrokeDescription(path, 0, (long) ((int) AutoClickSpeed.swipe_duration_time))).build(), (GestureResultCallback) null, (Handler) null);
        try {
            Log.d("After Target Num", String.valueOf(FloatingViewService.target_rotation));
            SharedPreferences sharedPreferences2 = FloatingViewService.settings;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("mPointer_Auto_After");
            stringBuilder2.append(String.valueOf(FloatingViewService.target_rotation));
            Thread.sleep((long) sharedPreferences2.getInt(stringBuilder2.toString(), 0));
        } catch (InterruptedException e2) {
            e2.printStackTrace();
        }
    }

    public boolean onUnbind(@Nullable Intent intent) {
        if (instance != null) {
            instance = null;
        }
        return super.onUnbind(intent);
    }

    public void onDestroy() {
        if (instance != null) {
            stopService(new Intent(getApplicationContext(), AutoClicker.class));
        }
        super.onDestroy();
    }
}
