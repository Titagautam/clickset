package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.TextView;
import android.widget.Toast;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import java.util.Random;

public class AutoClickSpeed extends Activity {
    public static boolean auto_flag;
    public static boolean back_flag;
    public static int clickpersecond;
    static Context context;
    static Drawable currDrawable1;
    static Drawable currDrawable2;
    static Drawable currDrawable3;
    static Drawable currDrawable4;
    static Drawable currDrawable5;
    public static double duration_time;
    public static double interval;
    public static ProgressDialog mDialog;
    public static boolean quick_flag;
    public static double start_time;
    public static double swipe_duration_time;
    public static boolean task_flag;
    public static boolean test_flag;
    private EditText Duration_Edt;
    private EditText Interval_Edt;
    private Button Reset_Btn;
    private ScrollView Rl;
    private Button Start_Btn;
    private Button Stop_Btn;
    private LinearLayout TestPanel_Lyt;
    private TextView Test_Num;
    private TextView a1;
    private TextView a2;
    private TextView a3;
    private View adContainer;
    private ImageView banner;
    Handler handler;
    private LayoutInflater inflater;
    private boolean loadingAd_flag;
    private int[] loc;
    private RelativeLayout mAssistiveView;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private ImageView pbanner;
    Runnable runnable;
    private int startCnt;
    private int style_num;
    private int style_type;
    private OnClickListener yesListener;

    public AutoClickSpeed() {
        this.loc = new int[2];
        this.yesListener = new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                AutoClickSpeed.this.launchMarket();
            }
        };
    }

    public AutoClickSpeed(Context context) {
        this.loc = new int[2];
        this.yesListener = /* anonymous class already generated */;
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_autoclickspeed);
        this.loadingAd_flag = true;
        if (FloatingViewService.mTracker != null) {
            FloatingViewService.mTracker.setScreenName("AutoClickSpeed");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        }
        getActionBar();
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mAssistiveView = (RelativeLayout) this.inflater.inflate(R.layout.activity_setting, null);
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return false;
        }
        onBackPressed();
        return true;
    }

    private boolean isMyServiceRunning(Class<?> cls) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        this.mShareActionProvider = (ShareActionProvider) menu.findItem(R.id.shareButton).getActionProvider();
        this.mShareActionProvider.setShareIntent(doShare());
        return true;
    }

    public Intent doShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Easy Touch & Assistive Touch & On-Screen-Pointer");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nLet me recommend you this application\n\n");
        stringBuilder.append("https://play.google.com/store/apps/details?id=com.auto.easytouch \n\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        return intent;
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        this.loadingAd_flag = false;
    }

    /* Access modifiers changed, original: protected */
    public void onPause() {
        super.onPause();
    }

    public boolean getRandomBoolean() {
        return new Random().nextBoolean();
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (FloatingViewService.mFloatingView == null || !(FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown())) {
            startService(new Intent(this, FloatingViewService.class));
        }
    }

    /* Access modifiers changed, original: 0000 */
    public double ParseDouble(String str) {
        if (str == null || str.length() <= 0) {
            return 0.0d;
        }
        try {
            return Double.parseDouble(str);
        } catch (Exception unused) {
            return -1.0d;
        }
    }

    /* Access modifiers changed, original: 0000 */
    public int ParseInt(String str) {
        if (str == null || str.length() <= 0) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception unused) {
            return -1;
        }
    }

    private void widget() {
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.Duration_Edt = (EditText) findViewById(R.id.duration_edt);
        this.Interval_Edt = (EditText) findViewById(R.id.interval_edt);
        this.Test_Num = (TextView) findViewById(R.id.test_num);
        if (FloatingViewService.settings.getInt("duration", -1) >= 0) {
            this.Duration_Edt.setText(String.valueOf(FloatingViewService.settings.getInt("duration", -1)));
        } else {
            this.Duration_Edt.setText(null);
        }
        if (clickpersecond == 30) {
            this.Interval_Edt.setText(null);
        } else {
            this.Interval_Edt.setText(String.valueOf(FloatingViewService.settings.getInt("clickpersecond", 30)));
        }
        this.TestPanel_Lyt = (LinearLayout) findViewById(R.id.test_panel);
        this.Start_Btn = (Button) findViewById(R.id.test_start);
        this.Stop_Btn = (Button) findViewById(R.id.test_stop);
        this.Reset_Btn = (Button) findViewById(R.id.test_reset);
        this.Duration_Edt.setSelection(this.Duration_Edt.getText().length());
        this.Interval_Edt.setSelection(this.Interval_Edt.getText().length());
        this.Duration_Edt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                Editor edit;
                if (AutoClickSpeed.this.ParseDouble(AutoClickSpeed.this.Duration_Edt.getText().toString()) > 0.0d && AutoClickSpeed.this.ParseDouble(AutoClickSpeed.this.Duration_Edt.getText().toString()) < 1000000.0d) {
                    AutoClickSpeed.duration_time = Double.parseDouble(AutoClickSpeed.this.Duration_Edt.getText().toString()) * 1000.0d;
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("duration", Integer.parseInt(AutoClickSpeed.this.Duration_Edt.getText().toString()));
                    edit.apply();
                } else if (AutoClickSpeed.this.ParseDouble(AutoClickSpeed.this.Duration_Edt.getText().toString()) > 1000000.0d) {
                    AutoClickSpeed.this.Duration_Edt.setText("1000000");
                    AutoClickSpeed.duration_time = Double.parseDouble(AutoClickSpeed.this.Duration_Edt.getText().toString()) * 1000.0d;
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("duration", Integer.parseInt(AutoClickSpeed.this.Duration_Edt.getText().toString()));
                    edit.apply();
                    Toast.makeText(AutoClickSpeed.this.getApplicationContext(), "Max duration seconds : 1000000 ", 0).show();
                } else {
                    AutoClickSpeed.duration_time = -1.0d;
                    Editor edit2 = FloatingViewService.settings.edit();
                    edit2.putInt("duration", -1);
                    edit2.apply();
                }
            }
        });
        this.Interval_Edt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                Editor edit;
                if (AutoClickSpeed.this.ParseInt(AutoClickSpeed.this.Interval_Edt.getText().toString()) > 50) {
                    AutoClickSpeed.this.Interval_Edt.setText("50");
                    AutoClickSpeed.clickpersecond = 50;
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("clickpersecond", 50);
                    edit.apply();
                    Toast.makeText(AutoClickSpeed.this.getApplicationContext(), "Max click per second : 50 ", 0).show();
                } else if (AutoClickSpeed.this.ParseInt(AutoClickSpeed.this.Interval_Edt.getText().toString()) > 0) {
                    AutoClickSpeed.clickpersecond = Integer.parseInt(AutoClickSpeed.this.Interval_Edt.getText().toString());
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("clickpersecond", Integer.parseInt(AutoClickSpeed.this.Interval_Edt.getText().toString()));
                    edit.apply();
                } else {
                    AutoClickSpeed.clickpersecond = 30;
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("clickpersecond", 30);
                    edit.apply();
                }
            }
        });
        this.TestPanel_Lyt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AutoClickSpeed.this.Test_Num.setText(String.valueOf(Integer.parseInt(AutoClickSpeed.this.Test_Num.getText().toString()) + 1));
            }
        });
        this.Stop_Btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AutoClickSpeed.test_flag = false;
            }
        });
        this.Reset_Btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AutoClickSpeed.this.Test_Num.setText("0");
            }
        });
        this.Start_Btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AutoClickSpeed.test_flag = true;
                AutoClickSpeed.start_time = (double) System.currentTimeMillis();
                final Handler handler = new Handler();
                handler.post(new Runnable() {
                    public void run() {
                        AutoClickSpeed.interval = ((double) System.currentTimeMillis()) - AutoClickSpeed.start_time;
                        if (AutoClickSpeed.test_flag && AutoClickSpeed.duration_time < 0.0d) {
                            AutoClickSpeed.this.Test_Num.setText(String.valueOf(Integer.parseInt(AutoClickSpeed.this.Test_Num.getText().toString()) + 1));
                            handler.postDelayed(this, (long) (1000 / AutoClickSpeed.clickpersecond));
                        } else if (AutoClickSpeed.test_flag && AutoClickSpeed.interval < AutoClickSpeed.duration_time) {
                            AutoClickSpeed.this.Test_Num.setText(String.valueOf(Integer.parseInt(AutoClickSpeed.this.Test_Num.getText().toString()) + 1));
                            handler.postDelayed(this, (long) (1000 / AutoClickSpeed.clickpersecond));
                        }
                    }
                });
            }
        });
    }

    private void launchMarket() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.auto.easytouchpropro")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    private void launchMarket2() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.dual.screen")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
