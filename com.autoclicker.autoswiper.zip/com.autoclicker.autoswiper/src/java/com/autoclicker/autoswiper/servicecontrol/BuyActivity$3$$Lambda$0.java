package com.autoclicker.autoswiper.servicecontrol;

import com.android.billingclient.api.SkuDetailsResponseListener;
import com.autoclicker.autoswiper.servicecontrol.BuyActivity.AnonymousClass3;
import java.util.List;

final /* synthetic */ class BuyActivity$3$$Lambda$0 implements SkuDetailsResponseListener {
    private final AnonymousClass3 arg$1;

    BuyActivity$3$$Lambda$0(AnonymousClass3 anonymousClass3) {
        this.arg$1 = anonymousClass3;
    }

    public void onSkuDetailsResponse(int i, List list) {
        this.arg$1.lambda$onBillingSetupFinished$0$BuyActivity$3(i, list);
    }
}
