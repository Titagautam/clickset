package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.autoclicker.autoswiper.BuildConfig;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import java.util.HashMap;
import java.util.List;

public class DelayActivity extends Activity implements PurchasesUpdatedListener {
    static Context context;
    private Button Btn_Initialize;
    private Button Btn_Initialize_All;
    private boolean Btn_Initialize_All_flag = false;
    private EditText Edt_After;
    private EditText Edt_Before;
    private LinearLayout Lyt_NO;
    private LinearLayout Lyt_OK;
    private ScrollView Rl;
    private boolean afterAd = false;
    private LayoutInflater inflater;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private HashMap<String, Object> properties;
    private String target_number;

    public void onPurchasesUpdated(int i, @Nullable List<Purchase> list) {
    }

    public DelayActivity(Context context) {
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LayoutParams layoutParams = new LayoutParams();
        layoutParams.flags = 2;
        layoutParams.dimAmount = 0.6f;
        getWindow().setAttributes(layoutParams);
        setContentView(R.layout.activity_delay);
        this.target_number = getIntent().getExtras().getString("target_number");
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
    }

    private void widget() {
        StringBuilder stringBuilder;
        String stringBuilder2;
        EditText editText;
        this.Edt_Before = (EditText) findViewById(R.id.edt_before);
        this.Edt_After = (EditText) findViewById(R.id.edt_after);
        SharedPreferences sharedPreferences = FloatingViewService.settings;
        sharedPreferences = FloatingViewService.settings;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("mPointer_Auto_Before");
        stringBuilder3.append(String.valueOf(this.target_number));
        if (sharedPreferences.getInt(stringBuilder3.toString(), 0) >= 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("setText mPointer_Auto_Before");
            stringBuilder.append(String.valueOf(this.target_number));
            stringBuilder2 = stringBuilder.toString();
            SharedPreferences sharedPreferences2 = FloatingViewService.settings;
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("mPointer_Auto_Before");
            stringBuilder4.append(String.valueOf(this.target_number));
            Log.d(stringBuilder2, String.valueOf(sharedPreferences2.getInt(stringBuilder4.toString(), 0)));
            editText = this.Edt_Before;
            sharedPreferences2 = FloatingViewService.settings;
            stringBuilder4 = new StringBuilder();
            stringBuilder4.append("mPointer_Auto_Before");
            stringBuilder4.append(String.valueOf(this.target_number));
            editText.setText(String.valueOf(sharedPreferences2.getInt(stringBuilder4.toString(), 0)));
        } else {
            this.Edt_Before.setText(null);
        }
        sharedPreferences = FloatingViewService.settings;
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append("mPointer_Auto_After");
        stringBuilder5.append(String.valueOf(this.target_number));
        if (sharedPreferences.getInt(stringBuilder5.toString(), 0) >= 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("setText mPointer_Auto_After");
            stringBuilder.append(String.valueOf(this.target_number));
            stringBuilder2 = stringBuilder.toString();
            SharedPreferences sharedPreferences3 = FloatingViewService.settings;
            stringBuilder5 = new StringBuilder();
            stringBuilder5.append("mPointer_Auto_After");
            stringBuilder5.append(String.valueOf(this.target_number));
            Log.d(stringBuilder2, String.valueOf(sharedPreferences3.getInt(stringBuilder5.toString(), 0)));
            editText = this.Edt_After;
            sharedPreferences3 = FloatingViewService.settings;
            stringBuilder5 = new StringBuilder();
            stringBuilder5.append("mPointer_Auto_After");
            stringBuilder5.append(String.valueOf(this.target_number));
            editText.setText(String.valueOf(sharedPreferences3.getInt(stringBuilder5.toString(), 0)));
        } else {
            this.Edt_After.setText(null);
        }
        this.Btn_Initialize = (Button) findViewById(R.id.btn_initialize);
        this.Btn_Initialize_All = (Button) findViewById(R.id.btn_initialize_all);
        this.Btn_Initialize.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DelayActivity.this.Edt_Before.setText("0");
                DelayActivity.this.Edt_After.setText("0");
                Editor edit = FloatingViewService.settings.edit();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("mPointer_Auto_Before");
                stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                edit.putInt(stringBuilder.toString(), 0);
                edit.apply();
            }
        });
        this.Btn_Initialize_All.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DelayActivity.this.Edt_Before.setText("0");
                DelayActivity.this.Edt_After.setText("0");
                Editor edit = FloatingViewService.settings.edit();
                for (int i = 1; i < 48; i++) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_Before");
                    stringBuilder.append(String.valueOf(i));
                    edit.putInt(stringBuilder.toString(), 0);
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_After");
                    stringBuilder.append(String.valueOf(i));
                    edit.putInt(stringBuilder.toString(), 0);
                }
                edit.apply();
            }
        });
        this.Lyt_OK = (LinearLayout) findViewById(R.id.lyt_ok);
        this.Lyt_OK.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Editor edit;
                StringBuilder stringBuilder;
                Log.d("target_number", String.valueOf(DelayActivity.this.target_number));
                Log.d("Edt_Before.getText()", DelayActivity.this.Edt_Before.getText().toString());
                Log.d("Edt_After.getText()", DelayActivity.this.Edt_After.getText().toString());
                if (DelayActivity.this.Edt_Before.getText().toString().equals(BuildConfig.FLAVOR)) {
                    edit = FloatingViewService.settings.edit();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_Before");
                    stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder.toString(), 0);
                    edit.apply();
                } else if (Integer.parseInt(DelayActivity.this.Edt_Before.getText().toString()) > 0) {
                    Log.d("Edt_Before.getText()", "more than zero");
                    edit = FloatingViewService.settings.edit();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_Before");
                    stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder.toString(), Integer.parseInt(DelayActivity.this.Edt_Before.getText().toString()));
                    edit.apply();
                } else {
                    edit = FloatingViewService.settings.edit();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_Before");
                    stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder.toString(), 0);
                    edit.apply();
                }
                if (DelayActivity.this.Edt_After.getText().toString().equals(BuildConfig.FLAVOR)) {
                    edit = FloatingViewService.settings.edit();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_After");
                    stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder.toString(), 0);
                    edit.apply();
                } else if (Integer.parseInt(DelayActivity.this.Edt_After.getText().toString()) > 0) {
                    Log.d("Edt_After.getText()", "more than zero");
                    edit = FloatingViewService.settings.edit();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("mPointer_Auto_After");
                    stringBuilder2.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder2.toString(), Integer.parseInt(DelayActivity.this.Edt_After.getText().toString()));
                    edit.apply();
                } else {
                    edit = FloatingViewService.settings.edit();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointer_Auto_After");
                    stringBuilder.append(String.valueOf(DelayActivity.this.target_number));
                    edit.putInt(stringBuilder.toString(), 0);
                    edit.apply();
                }
                DelayActivity.this.finish();
            }
        });
        this.Lyt_NO = (LinearLayout) findViewById(R.id.lyt_no);
        this.Lyt_NO.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                DelayActivity.this.finish();
            }
        });
    }
}
