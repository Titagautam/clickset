package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.Toast;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.Purchase.PurchasesResult;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsParams.Builder;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.autoclicker.autoswiper.billing.BillingConstants;
import com.autoclicker.autoswiper.billing.BillingManager;
import com.autoclicker.autoswiper.billing.BillingManager.BillingUpdatesListener;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BuyActivity extends Activity implements PurchasesUpdatedListener {
    static Context context;
    private LinearLayout Lyt_NO;
    private LinearLayout Lyt_OK;
    private ScrollView Rl;
    private boolean afterAd = false;
    private LayoutInflater inflater;
    private BillingClient mBillingClient;
    private BillingManager mBillingManager;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private HashMap<String, Object> properties;
    Purchase purchase;
    PurchasesResult purchasesResult;
    Builder skuDetailsParams;

    public void onPurchasesUpdated(int i, @Nullable List<Purchase> list) {
    }

    public BuyActivity(Context context) {
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LayoutParams layoutParams = new LayoutParams();
        layoutParams.flags = 2;
        layoutParams.dimAmount = 0.6f;
        getWindow().setAttributes(layoutParams);
        setContentView(R.layout.activity_buying);
        this.mBillingManager = new BillingManager(this, new BillingUpdatesListener() {
            public void onBillingClientSetupFinished() {
            }

            public void onConsumeFinished(String str, int i) {
            }

            public void onPurchasesUpdated(List<Purchase> list) {
            }
        });
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        if (this.mBillingManager != null) {
            this.mBillingManager.destroy();
        }
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (this.mBillingManager != null && this.mBillingManager.getBillingClientResponseCode() == 0) {
            this.mBillingManager.queryPurchases();
        }
    }

    private void widget() {
        this.Lyt_OK = (LinearLayout) findViewById(R.id.lyt_ok);
        this.Lyt_NO = (LinearLayout) findViewById(R.id.lyt_no);
        this.Lyt_NO.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                BuyActivity.this.finish();
            }
        });
        try {
            this.mBillingClient = BillingClient.newBuilder(this).setListener(this).build();
            this.mBillingClient.startConnection(new BillingClientStateListener() {
                public void onBillingSetupFinished(int i) {
                    if (i == 0) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(BillingConstants.SKU_PREMIUM);
                        BuyActivity.this.skuDetailsParams = SkuDetailsParams.newBuilder();
                        BuyActivity.this.skuDetailsParams.setSkusList(arrayList).setType("inapp");
                        BuyActivity.this.mBillingClient.querySkuDetailsAsync(BuyActivity.this.skuDetailsParams.build(), new BuyActivity$3$$Lambda$0(this));
                        BuyActivity.this.mBillingClient.queryPurchaseHistoryAsync("inapp", new PurchaseHistoryResponseListener() {
                            public void onPurchaseHistoryResponse(int i, List<Purchase> list) {
                            }
                        });
                        BuyActivity.this.mBillingManager.queryPurchases();
                        if (FloatingViewService.purchased) {
                            Log.d("FloatingViewService.purchased == true : ", "true");
                            FloatingViewService.purchase_num = 48;
                        }
                    }
                }

                /* Access modifiers changed, original: final|synthetic */
                public final /* synthetic */ void lambda$onBillingSetupFinished$0$BuyActivity$3(int i, final List list) {
                    if (i == 0 && list != null) {
                        for (SkuDetails skuDetails : list) {
                            skuDetails.getSku();
                            skuDetails.getPrice();
                            Log.d("sku : ", String.valueOf(skuDetails.getSku()));
                            Log.d("price : ", String.valueOf(skuDetails.getPrice()));
                        }
                        Log.d("skuDetailsList.Size() : ", String.valueOf(list.size()));
                        BuyActivity.this.Lyt_OK.setOnClickListener(new OnClickListener() {
                            public void onClick(View view) {
                                FloatingViewService.mTracker.setScreenName("Automatic Clicker Remove Ads");
                                FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
                                Log.d("skuDetailsList Size : ", String.valueOf(list.size()));
                                BuyActivity.this.mBillingClient.launchBillingFlow(BuyActivity.this, BillingFlowParams.newBuilder().setSkuDetails((SkuDetails) list.get(0)).build());
                            }
                        });
                    }
                }

                public void onBillingServiceDisconnected() {
                    Toast.makeText(BuyActivity.this.getApplicationContext(), "Check your connection", 0).show();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
