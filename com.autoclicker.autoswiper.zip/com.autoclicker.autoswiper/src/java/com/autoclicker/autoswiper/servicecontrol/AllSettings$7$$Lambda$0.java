package com.autoclicker.autoswiper.servicecontrol;

import com.android.billingclient.api.SkuDetailsResponseListener;
import com.autoclicker.autoswiper.servicecontrol.AllSettings.AnonymousClass7;
import java.util.List;

final /* synthetic */ class AllSettings$7$$Lambda$0 implements SkuDetailsResponseListener {
    private final AnonymousClass7 arg$1;

    AllSettings$7$$Lambda$0(AnonymousClass7 anonymousClass7) {
        this.arg$1 = anonymousClass7;
    }

    public void onSkuDetailsResponse(int i, List list) {
        this.arg$1.lambda$onBillingSetupFinished$0$AllSettings$7(i, list);
    }
}
