package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.ShareActionProvider.OnShareTargetSelectedListener;
import android.widget.Toast;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import java.util.HashMap;

public class RateActivity extends Activity {
    static Context context;
    private LinearLayout Lyt_Later;
    private LinearLayout Lyt_Rate;
    private ScrollView Rl;
    private boolean afterAd = false;
    private int bannerNum = 1;
    private int banner_change = 0;
    private View decorView;
    Handler handler;
    private LayoutInflater inflater;
    private boolean loadingAd_flag;
    private RelativeLayout mAssistiveView;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private ImageView pbanner;
    private HashMap<String, Object> properties;
    private boolean rating_drag_flag = false;
    private RelativeLayout rl;
    Runnable runnable;
    private int stars;
    private int startCnt;
    private int style_num;
    private int style_type;
    private OnClickListener yesListener = new OnClickListener() {
        public void onClick(DialogInterface dialogInterface, int i) {
            RateActivity.this.launchMarket();
        }
    };

    public RateActivity(Context context) {
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LayoutParams layoutParams = new LayoutParams();
        layoutParams.flags = 2;
        layoutParams.dimAmount = 0.6f;
        getWindow().setAttributes(layoutParams);
        setContentView(R.layout.activity_rating);
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    private void launchMarket() {
        if (FloatingViewService.mTracker != null) {
            FloatingViewService.mTracker.setScreenName("RateActivity - go rating - ");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        }
        Editor edit = FloatingViewService.settings.edit();
        edit.putBoolean("rate", true);
        edit.apply();
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.autoclicker.autoswiper"));
        try {
            Toast.makeText(getApplicationContext(), "Thank you for your support! :)", 0).show();
            startActivity(intent);
            finish();
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        this.mShareActionProvider = (ShareActionProvider) menu.findItem(R.id.shareButton).getActionProvider();
        this.mShareActionProvider.setShareIntent(doShare());
        this.mShareActionProvider.setOnShareTargetSelectedListener(new OnShareTargetSelectedListener() {
            public boolean onShareTargetSelected(ShareActionProvider shareActionProvider, Intent intent) {
                ((TelephonyManager) RateActivity.this.getSystemService("phone")).getNetworkCountryIso();
                FloatingViewService.rate_flag = true;
                Toast.makeText(RateActivity.this.getApplicationContext(), "Thank you for sharing this app! :)", 0).show();
                Log.d("do share", "clicked");
                return false;
            }
        });
        return true;
    }

    public Intent doShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Easy Touch & Assistive Touch & On-Screen-Pointer");
        String string = getResources().getString(R.string.recommend_app);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append("https://play.google.com/store/apps/details?id=com.autoclicker.autoswiper \n\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        return intent;
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        FloatingViewService.settings = PreferenceManager.getDefaultSharedPreferences(this);
        this.startCnt = FloatingViewService.settings.getInt("start_cnt", 0) + 1;
        Editor edit = FloatingViewService.settings.edit();
        edit.putInt("start_cnt", this.startCnt);
        edit.apply();
    }

    private void widget() {
        this.Lyt_Rate = (LinearLayout) findViewById(R.id.lyt_rate);
        this.Lyt_Rate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Editor edit = FloatingViewService.settings.edit();
                edit.putBoolean("rate", true);
                edit.apply();
                RateActivity.this.launchMarket();
            }
        });
        this.Lyt_Later = (LinearLayout) findViewById(R.id.lyt_later);
        this.Lyt_Later.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RateActivity.this.finish();
            }
        });
    }
}
