package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ShareActionProvider;
import android.widget.Toast;
import com.autoclicker.autoswiper.BuildConfig;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.autoclicker.autoswiper.ViewPointerAuto;
import com.autoclicker.autoswiper.ViewPointerAutoSwipe;
import com.autoclicker.autoswiper.save.SaveItem;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Configuration extends Activity {
    static Context context;
    private LayoutInflater inflater;
    public ArrayList<Integer> item_px = new ArrayList();
    public ArrayList<Integer> item_py = new ArrayList();
    private Button l1;
    private Button l10;
    private Button l2;
    private Button l3;
    private Button l4;
    private Button l5;
    private Button l6;
    private Button l7;
    private Button l8;
    private Button l9;
    private boolean loadingAd_flag;
    private RelativeLayout mAssistiveView;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private Button s1;
    private Button s10;
    private Button s2;
    private Button s3;
    private Button s4;
    private Button s5;
    private Button s6;
    private Button s7;
    private Button s8;
    private Button s9;
    private OnClickListener yesListener = new OnClickListener() {
        public void onClick(DialogInterface dialogInterface, int i) {
            Configuration.this.launchMarket();
        }
    };

    public Configuration(Context context) {
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_configuration);
        this.loadingAd_flag = true;
        if (FloatingViewService.mTracker != null) {
            FloatingViewService.mTracker.setScreenName("AutoClickSave");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        }
        getActionBar();
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mAssistiveView = (RelativeLayout) this.inflater.inflate(R.layout.activity_setting, null);
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return false;
        }
        onBackPressed();
        return true;
    }

    private boolean isMyServiceRunning(Class<?> cls) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        this.mShareActionProvider = (ShareActionProvider) menu.findItem(R.id.shareButton).getActionProvider();
        this.mShareActionProvider.setShareIntent(doShare());
        return true;
    }

    public Intent doShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Easy Touch & Assistive Touch & On-Screen-Pointer");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nLet me recommend you this application\n\n");
        stringBuilder.append("https://play.google.com/store/apps/details?id=com.auto.easytouch \n\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        return intent;
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        this.loadingAd_flag = false;
    }

    /* Access modifiers changed, original: protected */
    public void onPause() {
        super.onPause();
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (FloatingViewService.mFloatingView == null || !(FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown())) {
            startService(new Intent(this, FloatingViewService.class));
        }
    }

    private void widget() {
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.s1 = (Button) findViewById(R.id.save1);
        this.s2 = (Button) findViewById(R.id.save2);
        this.s3 = (Button) findViewById(R.id.save3);
        this.s4 = (Button) findViewById(R.id.save4);
        this.s5 = (Button) findViewById(R.id.save5);
        this.s6 = (Button) findViewById(R.id.save6);
        this.s7 = (Button) findViewById(R.id.save7);
        this.s8 = (Button) findViewById(R.id.save8);
        this.s9 = (Button) findViewById(R.id.save9);
        this.s10 = (Button) findViewById(R.id.save10);
        this.l1 = (Button) findViewById(R.id.load1);
        this.l2 = (Button) findViewById(R.id.load2);
        this.l3 = (Button) findViewById(R.id.load3);
        this.l4 = (Button) findViewById(R.id.load4);
        this.l5 = (Button) findViewById(R.id.load5);
        this.l6 = (Button) findViewById(R.id.load6);
        this.l7 = (Button) findViewById(R.id.load7);
        this.l8 = (Button) findViewById(R.id.load8);
        this.l9 = (Button) findViewById(R.id.load9);
        this.l10 = (Button) findViewById(R.id.load10);
        this.s1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    view = FloatingViewService.mFloatingView;
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot1", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save1", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save1", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR) || FloatingViewService.isViewCollapsed()) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot1", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot1", 0).show();
                }
            }
        });
        this.s2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot2", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save2", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save2", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR)) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot2", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot2", 0).show();
                }
            }
        });
        this.s3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot3", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save3", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save3", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR)) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot3", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot3", 0).show();
                }
            }
        });
        this.s4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot4", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save4", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save4", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR)) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot4", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot4", 0).show();
                }
            }
        });
        this.s5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot5", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save5", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save5", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR)) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot5", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot5", 0).show();
                }
            }
        });
        this.s6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot6", 0).show();
                    SaveItem saveItem = new SaveItem();
                    Editor edit = FloatingViewService.settings.edit();
                    edit.putString("save6", new Gson().toJson(saveItem));
                    edit.commit();
                }
            }
        });
        this.l6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    String string = FloatingViewService.settings.getString("save6", BuildConfig.FLAVOR);
                    if (string.equals(BuildConfig.FLAVOR)) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot6", 0).show();
                        return;
                    }
                    System.out.print(string);
                    SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                    Configuration.this.remvoe_PointerViewAll();
                    FloatingViewService.target_num = 0;
                    FloatingViewService.swipe_target = saveItem.getSwipe_target();
                    Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 1;
                    for (int i2 = 1; i2 < 48; i2++) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_Before");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointer_Auto_After");
                        stringBuilder.append(String.valueOf(i2));
                        edit.putInt(stringBuilder.toString(), 0);
                    }
                    edit.apply();
                    while (i <= saveItem.getPx().size()) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_Before");
                        stringBuilder2.append(String.valueOf(i));
                        String stringBuilder3 = stringBuilder2.toString();
                        Map delay_target = saveItem.getDelay_target();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_Before");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointer_Auto_After");
                        stringBuilder2.append(String.valueOf(i));
                        stringBuilder3 = stringBuilder2.toString();
                        delay_target = saveItem.getDelay_target();
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointer_Auto_After");
                        stringBuilder4.append(String.valueOf(i));
                        edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                        i++;
                    }
                    edit.apply();
                    Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot6", 0).show();
                }
            }
        });
        this.s7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    if (FloatingViewService.purchased) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot7", 0).show();
                        SaveItem saveItem = new SaveItem();
                        Editor edit = FloatingViewService.settings.edit();
                        edit.putString("save7", new Gson().toJson(saveItem));
                        edit.commit();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.l7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    int i = 1;
                    if (FloatingViewService.purchased) {
                        String string = FloatingViewService.settings.getString("save7", BuildConfig.FLAVOR);
                        if (string.equals(BuildConfig.FLAVOR)) {
                            Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot7", 0).show();
                            return;
                        }
                        System.out.print(string);
                        SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                        Configuration.this.remvoe_PointerViewAll();
                        FloatingViewService.target_num = 0;
                        FloatingViewService.swipe_target = saveItem.getSwipe_target();
                        Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                        Editor edit = FloatingViewService.settings.edit();
                        for (int i2 = 1; i2 < 48; i2++) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_Before");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_After");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                        }
                        edit.apply();
                        while (i <= saveItem.getPx().size()) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_Before");
                            stringBuilder2.append(String.valueOf(i));
                            String stringBuilder3 = stringBuilder2.toString();
                            Map delay_target = saveItem.getDelay_target();
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_Before");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_After");
                            stringBuilder2.append(String.valueOf(i));
                            stringBuilder3 = stringBuilder2.toString();
                            delay_target = saveItem.getDelay_target();
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_After");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            i++;
                        }
                        edit.apply();
                        Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot7", 0).show();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.s8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    if (FloatingViewService.purchased) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot8", 0).show();
                        SaveItem saveItem = new SaveItem();
                        Editor edit = FloatingViewService.settings.edit();
                        edit.putString("save8", new Gson().toJson(saveItem));
                        edit.commit();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.l8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    int i = 1;
                    if (FloatingViewService.purchased) {
                        String string = FloatingViewService.settings.getString("save8", BuildConfig.FLAVOR);
                        if (string.equals(BuildConfig.FLAVOR)) {
                            Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot8", 0).show();
                            return;
                        }
                        System.out.print(string);
                        SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                        Configuration.this.remvoe_PointerViewAll();
                        FloatingViewService.target_num = 0;
                        FloatingViewService.swipe_target = saveItem.getSwipe_target();
                        Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                        Editor edit = FloatingViewService.settings.edit();
                        for (int i2 = 1; i2 < 48; i2++) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_Before");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_After");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                        }
                        edit.apply();
                        while (i <= saveItem.getPx().size()) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_Before");
                            stringBuilder2.append(String.valueOf(i));
                            String stringBuilder3 = stringBuilder2.toString();
                            Map delay_target = saveItem.getDelay_target();
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_Before");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_After");
                            stringBuilder2.append(String.valueOf(i));
                            stringBuilder3 = stringBuilder2.toString();
                            delay_target = saveItem.getDelay_target();
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_After");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            i++;
                        }
                        edit.apply();
                        Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot8", 0).show();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.s9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    if (FloatingViewService.purchased) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot9", 0).show();
                        SaveItem saveItem = new SaveItem();
                        Editor edit = FloatingViewService.settings.edit();
                        edit.putString("save9", new Gson().toJson(saveItem));
                        edit.commit();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.l9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    int i = 1;
                    if (FloatingViewService.purchased) {
                        String string = FloatingViewService.settings.getString("save9", BuildConfig.FLAVOR);
                        if (string.equals(BuildConfig.FLAVOR)) {
                            Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot9", 0).show();
                            return;
                        }
                        System.out.print(string);
                        SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                        Configuration.this.remvoe_PointerViewAll();
                        FloatingViewService.target_num = 0;
                        FloatingViewService.swipe_target = saveItem.getSwipe_target();
                        Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                        Editor edit = FloatingViewService.settings.edit();
                        for (int i2 = 1; i2 < 48; i2++) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_Before");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_After");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                        }
                        edit.apply();
                        while (i <= saveItem.getPx().size()) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_Before");
                            stringBuilder2.append(String.valueOf(i));
                            String stringBuilder3 = stringBuilder2.toString();
                            Map delay_target = saveItem.getDelay_target();
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_Before");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_After");
                            stringBuilder2.append(String.valueOf(i));
                            stringBuilder3 = stringBuilder2.toString();
                            delay_target = saveItem.getDelay_target();
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_After");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            i++;
                        }
                        edit.apply();
                        Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot9", 0).show();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.s10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    if (FloatingViewService.purchased) {
                        Toast.makeText(Configuration.this.getApplicationContext(), "Saved Slot10", 0).show();
                        SaveItem saveItem = new SaveItem();
                        Editor edit = FloatingViewService.settings.edit();
                        edit.putString("save10", new Gson().toJson(saveItem));
                        edit.commit();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
        this.l10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (FloatingViewService.mFloatingView == null) {
                    return;
                }
                if (FloatingViewService.mFloatingView == null || FloatingViewService.mFloatingView.isShown()) {
                    if (FloatingViewService.mFloatingView != null && FloatingViewService.isViewCollapsed()) {
                        FloatingViewService.expandView();
                    }
                    int i = 1;
                    if (FloatingViewService.purchased) {
                        String string = FloatingViewService.settings.getString("save10", BuildConfig.FLAVOR);
                        if (string.equals(BuildConfig.FLAVOR)) {
                            Toast.makeText(Configuration.this.getApplicationContext(), "Empty Slot10", 0).show();
                            return;
                        }
                        System.out.print(string);
                        SaveItem saveItem = (SaveItem) new Gson().fromJson(string, SaveItem.class);
                        Configuration.this.remvoe_PointerViewAll();
                        FloatingViewService.target_num = 0;
                        FloatingViewService.swipe_target = saveItem.getSwipe_target();
                        Configuration.this.put_PointerViewAuto(saveItem.getPx(), saveItem.getPy());
                        Editor edit = FloatingViewService.settings.edit();
                        for (int i2 = 1; i2 < 48; i2++) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_Before");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointer_Auto_After");
                            stringBuilder.append(String.valueOf(i2));
                            edit.putInt(stringBuilder.toString(), 0);
                        }
                        edit.apply();
                        while (i <= saveItem.getPx().size()) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_Before");
                            stringBuilder2.append(String.valueOf(i));
                            String stringBuilder3 = stringBuilder2.toString();
                            Map delay_target = saveItem.getDelay_target();
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_Before");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointer_Auto_After");
                            stringBuilder2.append(String.valueOf(i));
                            stringBuilder3 = stringBuilder2.toString();
                            delay_target = saveItem.getDelay_target();
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointer_Auto_After");
                            stringBuilder4.append(String.valueOf(i));
                            edit.putInt(stringBuilder3, ((Integer) delay_target.get(stringBuilder4.toString())).intValue());
                            i++;
                        }
                        edit.apply();
                        Toast.makeText(Configuration.this.getApplicationContext(), "Loaded Slot10", 0).show();
                        return;
                    }
                    Toast.makeText(Configuration.this.getApplicationContext(), Configuration.this.getResources().getText(R.string.purchase_yet), 0).show();
                }
            }
        });
    }

    private void put_PointerViewAuto(ArrayList<Integer> arrayList, ArrayList<Integer> arrayList2) {
        ArrayList<Integer> arrayList3 = arrayList;
        ArrayList<Integer> arrayList4 = arrayList2;
        int i = 2038;
        int i2 = VERSION.SDK_INT >= 26 ? 2038 : 2003;
        if (VERSION.SDK_INT < 26) {
            i = 2006;
        }
        Editor edit = FloatingViewService.settings.edit();
        int i3 = 1;
        int i4 = 1;
        while (i4 <= arrayList.size()) {
            StringBuilder stringBuilder;
            int i5;
            Log.d("swipe size", String.valueOf(FloatingViewService.swipe_target.size()));
            int i6 = 0;
            int i7 = 0;
            while (i6 < FloatingViewService.swipe_target.size()) {
                stringBuilder = new StringBuilder();
                stringBuilder.append(String.valueOf(i4));
                stringBuilder.append(", ");
                stringBuilder.append(String.valueOf(FloatingViewService.swipe_target.get(i6)));
                Log.d("i / swipe_target num", stringBuilder.toString());
                if (i4 == ((Integer) FloatingViewService.swipe_target.get(i6)).intValue()) {
                    i7 = i3;
                }
                i6++;
            }
            Log.d("swipe flag", "true");
            StringBuilder stringBuilder2;
            Map map;
            StringBuilder stringBuilder3;
            Map map2;
            StringBuilder stringBuilder4;
            if (i7 == i3) {
                i5 = i4 + 1;
                FloatingViewService.target_num += i3;
                Log.d("target_num", String.valueOf(FloatingViewService.target_num));
                Log.d("target_num-1", String.valueOf(FloatingViewService.target_num - i3));
                Map map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), new ViewPointerAuto(getApplicationContext()));
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setClickable(i3);
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setFocusable(i3);
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                LayoutParams layoutParams = r6;
                String stringBuilder5 = stringBuilder2.toString();
                LayoutParams layoutParams2 = new LayoutParams(-2, -2, i2, 8, -3);
                map3.put(stringBuilder5, layoutParams);
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).gravity = 51;
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).x = ((Integer) arrayList3.get(FloatingViewService.target_num - 1)).intValue();
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).y = ((Integer) arrayList4.get(FloatingViewService.target_num - 1)).intValue();
                StringBuilder stringBuilder6 = new StringBuilder();
                stringBuilder6.append("@drawable/sarget");
                stringBuilder6.append(String.valueOf(FloatingViewService.target_num));
                final int identifier = getResources().getIdentifier(stringBuilder6.toString(), null, getPackageName());
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setBackgroundResource(identifier);
                map3 = FloatingViewService.px_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("px_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                map3 = FloatingViewService.py_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("py_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), new ViewPointerAutoSwipe(getApplicationContext()));
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAutoSwipe) map3.get(stringBuilder2.toString())).setClickable(true);
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAutoSwipe) map3.get(stringBuilder2.toString())).setFocusable(true);
                Map map4 = FloatingViewService.mParams_auto;
                stringBuilder6 = new StringBuilder();
                stringBuilder6.append("mParams_auto_s");
                stringBuilder6.append(String.valueOf(FloatingViewService.target_num));
                LayoutParams layoutParams3 = r5;
                String stringBuilder7 = stringBuilder6.toString();
                LayoutParams layoutParams4 = new LayoutParams(-1, -1, i, 262456, -3);
                map4.put(stringBuilder7, layoutParams3);
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).gravity = 51;
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).x = ((Integer) arrayList3.get(FloatingViewService.target_num - 1)).intValue();
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).y = ((Integer) arrayList4.get(FloatingViewService.target_num - 1)).intValue();
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map3.get(stringBuilder2.toString());
                ViewPointerAutoSwipe.draw_flag = true;
                WindowManager windowManager = this.mWindowManager;
                map = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto_s");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                View view = (View) map.get(stringBuilder3.toString());
                map2 = FloatingViewService.mParams_auto;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append("mParams_auto_s");
                stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                windowManager.addView(view, (ViewGroup.LayoutParams) map2.get(stringBuilder4.toString()));
                Log.d("adjust x", String.valueOf(FloatingViewService.deviceHeight / 15));
                Log.d("adjust y", String.valueOf(FloatingViewService.deviceHeight / 15));
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAutoSwipe) map3.get(stringBuilder2.toString())).assign(((Integer) arrayList3.get(FloatingViewService.target_num - 1)).intValue() + ((FloatingViewService.deviceHeight / 15) / 2), ((Integer) arrayList4.get(FloatingViewService.target_num - 1)).intValue() + (FloatingViewService.deviceHeight / 15), ((Integer) arrayList3.get(FloatingViewService.target_num)).intValue() + ((FloatingViewService.deviceHeight / 15) / 2), ((Integer) arrayList4.get(FloatingViewService.target_num)).intValue() + (FloatingViewService.deviceHeight / 15));
                map3 = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto_s");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAutoSwipe) map3.get(stringBuilder2.toString())).invalidate();
                windowManager = this.mWindowManager;
                map = FloatingViewService.mPointerView_auto_swipe;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto_s");
                stringBuilder3.append(FloatingViewService.target_num);
                view = (View) map.get(stringBuilder3.toString());
                map2 = FloatingViewService.mParams_auto;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append("mParams_auto_s");
                stringBuilder4.append(FloatingViewService.target_num);
                windowManager.updateViewLayout(view, (ViewGroup.LayoutParams) map2.get(stringBuilder4.toString()));
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setOnTouchListener(new OnTouchListener() {
                    private float initialPointX;
                    private float initialPointY;
                    private int initialX;
                    private int initialY;
                    private String touch_target_num;
                    private int vectorX;
                    private int vectorY;

                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        try {
                            Map map;
                            StringBuilder stringBuilder;
                            Map map2;
                            StringBuilder stringBuilder2;
                            StringBuilder stringBuilder3;
                            Map map3;
                            StringBuilder stringBuilder4;
                            int rawY;
                            switch (motionEvent.getAction()) {
                                case 0:
                                    String resourceEntryName = view.getResources().getResourceEntryName(identifier);
                                    if (resourceEntryName.length() > 7) {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    } else {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    }
                                    Editor edit = FloatingViewService.settings.edit();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                    edit.apply();
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                    this.initialPointX = motionEvent.getRawX();
                                    this.initialPointY = motionEvent.getRawY();
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("px_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    String stringBuilder5 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto");
                                    stringBuilder4.append(this.touch_target_num);
                                    map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("py_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    stringBuilder5 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto");
                                    stringBuilder4.append(this.touch_target_num);
                                    map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).y));
                                    break;
                                case 1:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_up", stringBuilder2.toString());
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("px_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    String stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("py_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                    int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                        Intent intent = new Intent(Configuration.this.getApplicationContext(), DelayActivity.class);
                                        intent.setFlags(268435456);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("target_number", this.touch_target_num);
                                        intent.putExtras(bundle);
                                        Configuration.this.startActivity(intent);
                                        break;
                                    }
                                case 2:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_move", stringBuilder2.toString());
                                    this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                    WindowManager windowManager = Configuration.this.mWindowManager;
                                    Map map4 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    View view2 = (View) map4.get(stringBuilder2.toString());
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder.toString()));
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(this.touch_target_num));
                                    ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                    ViewPointerAutoSwipe.draw_flag = true;
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(this.touch_target_num));
                                    viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                    map4 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    rawY = ((LayoutParams) map4.get(stringBuilder2.toString())).x;
                                    map3 = FloatingViewService.mPointerView_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mPointerView_auto");
                                    stringBuilder.append(String.valueOf(this.touch_target_num));
                                    rawY += ((ViewPointerAuto) map3.get(stringBuilder.toString())).getWidth() / 2;
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    int i = ((LayoutParams) map3.get(stringBuilder.toString())).y;
                                    Map map5 = FloatingViewService.mPointerView_auto;
                                    StringBuilder stringBuilder7 = new StringBuilder();
                                    stringBuilder7.append("mPointerView_auto");
                                    stringBuilder7.append(String.valueOf(this.touch_target_num));
                                    i += ((ViewPointerAuto) map5.get(stringBuilder7.toString())).getWidth();
                                    map5 = FloatingViewService.mParams_auto;
                                    stringBuilder7 = new StringBuilder();
                                    stringBuilder7.append("mParams_auto");
                                    stringBuilder7.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() + 1));
                                    int i2 = ((LayoutParams) map5.get(stringBuilder7.toString())).x;
                                    Map map6 = FloatingViewService.mPointerView_auto;
                                    StringBuilder stringBuilder8 = new StringBuilder();
                                    stringBuilder8.append("mPointerView_auto");
                                    stringBuilder8.append(String.valueOf(this.touch_target_num));
                                    i2 += ((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth() / 2;
                                    map6 = FloatingViewService.mParams_auto;
                                    stringBuilder8 = new StringBuilder();
                                    stringBuilder8.append("mParams_auto");
                                    stringBuilder8.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() + 1));
                                    int i3 = ((LayoutParams) map6.get(stringBuilder8.toString())).y;
                                    map6 = FloatingViewService.mPointerView_auto;
                                    stringBuilder8 = new StringBuilder();
                                    stringBuilder8.append("mPointerView_auto");
                                    stringBuilder8.append(String.valueOf(this.touch_target_num));
                                    viewPointerAutoSwipe.assign(rawY, i, i2, i3 + ((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth());
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(this.touch_target_num));
                                    ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                    windowManager = Configuration.this.mWindowManager;
                                    map4 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto_s");
                                    stringBuilder2.append(this.touch_target_num);
                                    view2 = (View) map4.get(stringBuilder2.toString());
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto_s");
                                    stringBuilder4.append(this.touch_target_num);
                                    windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                    break;
                                default:
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return false;
                    }
                });
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                if (map3.get(stringBuilder2.toString()) != null) {
                    map3 = FloatingViewService.mPointerView_auto;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("mPointerView_auto");
                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                    if (!((ViewPointerAuto) map3.get(stringBuilder2.toString())).isShown()) {
                        windowManager = this.mWindowManager;
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mPointerView_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        view = (View) map.get(stringBuilder3.toString());
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mParams_auto");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        windowManager.addView(view, (ViewGroup.LayoutParams) map2.get(stringBuilder4.toString()));
                    }
                }
                edit.putInt("auto_target", FloatingViewService.target_num);
                edit.apply();
                Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
                FloatingViewService.target_num++;
                map3 = FloatingViewService.px_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("px_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                map3 = FloatingViewService.py_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("py_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), new ViewPointerAuto(getApplicationContext()));
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setClickable(true);
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map3.get(stringBuilder2.toString())).setFocusable(true);
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map3.put(stringBuilder2.toString(), new LayoutParams(-2, -2, i2, 8, -3));
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).gravity = 51;
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).x = ((Integer) arrayList3.get(FloatingViewService.target_num - 1)).intValue();
                map3 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map3.get(stringBuilder2.toString())).y = ((Integer) arrayList4.get(FloatingViewService.target_num - 1)).intValue();
                stringBuilder6 = new StringBuilder();
                stringBuilder6.append("@drawable/sarget");
                stringBuilder6.append(String.valueOf(FloatingViewService.target_num));
                i4 = getResources().getIdentifier(stringBuilder6.toString(), null, getPackageName());
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map.get(stringBuilder3.toString())).setBackgroundResource(i4);
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map.get(stringBuilder3.toString())).setOnTouchListener(new OnTouchListener() {
                    private float initialPointX;
                    private float initialPointY;
                    private int initialX;
                    private int initialY;
                    private String touch_target_num;
                    private int vectorX;
                    private int vectorY;

                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        try {
                            Map map;
                            StringBuilder stringBuilder;
                            Map map2;
                            StringBuilder stringBuilder2;
                            StringBuilder stringBuilder3;
                            Map map3;
                            int rawY;
                            switch (motionEvent.getAction()) {
                                case 0:
                                    String resourceEntryName = view.getResources().getResourceEntryName(i4);
                                    if (resourceEntryName.length() > 7) {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    } else {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    }
                                    Editor edit = FloatingViewService.settings.edit();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                    edit.apply();
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                    this.initialPointX = motionEvent.getRawX();
                                    this.initialPointY = motionEvent.getRawY();
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("px_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    String stringBuilder4 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    StringBuilder stringBuilder5 = new StringBuilder();
                                    stringBuilder5.append("mParams_auto");
                                    stringBuilder5.append(this.touch_target_num);
                                    map2.put(stringBuilder4, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder5.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("py_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    stringBuilder4 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder5 = new StringBuilder();
                                    stringBuilder5.append("mParams_auto");
                                    stringBuilder5.append(this.touch_target_num);
                                    map2.put(stringBuilder4, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder5.toString())).y));
                                    break;
                                case 1:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_up", stringBuilder2.toString());
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("px_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    String stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("py_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                    int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                        Intent intent = new Intent(Configuration.this.getApplicationContext(), DelayActivity.class);
                                        intent.setFlags(268435456);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("target_number", this.touch_target_num);
                                        intent.putExtras(bundle);
                                        Configuration.this.startActivity(intent);
                                        break;
                                    }
                                case 2:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_move", stringBuilder2.toString());
                                    this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                    WindowManager windowManager = Configuration.this.mWindowManager;
                                    Map map4 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    View view2 = (View) map4.get(stringBuilder2.toString());
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder.toString()));
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(this.touch_target_num));
                                    ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                    ViewPointerAutoSwipe.draw_flag = true;
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                    viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                    map4 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                    rawY = ((LayoutParams) map4.get(stringBuilder2.toString())).x;
                                    map3 = FloatingViewService.mPointerView_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mPointerView_auto");
                                    stringBuilder.append(String.valueOf(this.touch_target_num));
                                    rawY += ((ViewPointerAuto) map3.get(stringBuilder.toString())).getWidth() / 2;
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                    int i = ((LayoutParams) map3.get(stringBuilder.toString())).y;
                                    Map map5 = FloatingViewService.mPointerView_auto;
                                    StringBuilder stringBuilder7 = new StringBuilder();
                                    stringBuilder7.append("mPointerView_auto");
                                    stringBuilder7.append(String.valueOf(this.touch_target_num));
                                    i += ((ViewPointerAuto) map5.get(stringBuilder7.toString())).getWidth();
                                    map5 = FloatingViewService.mParams_auto;
                                    stringBuilder7 = new StringBuilder();
                                    stringBuilder7.append("mParams_auto");
                                    stringBuilder7.append(this.touch_target_num);
                                    int i2 = ((LayoutParams) map5.get(stringBuilder7.toString())).x;
                                    Map map6 = FloatingViewService.mPointerView_auto;
                                    StringBuilder stringBuilder8 = new StringBuilder();
                                    stringBuilder8.append("mPointerView_auto");
                                    stringBuilder8.append(String.valueOf(this.touch_target_num));
                                    i2 += ((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth() / 2;
                                    map6 = FloatingViewService.mParams_auto;
                                    stringBuilder8 = new StringBuilder();
                                    stringBuilder8.append("mParams_auto");
                                    stringBuilder8.append(this.touch_target_num);
                                    int i3 = ((LayoutParams) map6.get(stringBuilder8.toString())).y;
                                    Map map7 = FloatingViewService.mPointerView_auto;
                                    StringBuilder stringBuilder9 = new StringBuilder();
                                    stringBuilder9.append("mPointerView_auto");
                                    stringBuilder9.append(String.valueOf(this.touch_target_num));
                                    viewPointerAutoSwipe.assign(rawY, i, i2, i3 + ((ViewPointerAuto) map7.get(stringBuilder9.toString())).getWidth());
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                    ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                    windowManager = Configuration.this.mWindowManager;
                                    map4 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto_s");
                                    stringBuilder2.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                    view2 = (View) map4.get(stringBuilder2.toString());
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto_s");
                                    stringBuilder.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                    windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder.toString()));
                                    break;
                                default:
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return false;
                    }
                });
                map3 = FloatingViewService.mPointerView_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mPointerView_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                if (map3.get(stringBuilder2.toString()) != null) {
                    map3 = FloatingViewService.mPointerView_auto;
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("mPointerView_auto");
                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                    if (!((ViewPointerAuto) map3.get(stringBuilder2.toString())).isShown()) {
                        windowManager = this.mWindowManager;
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mPointerView_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        view = (View) map.get(stringBuilder3.toString());
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mParams_auto");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        windowManager.addView(view, (ViewGroup.LayoutParams) map2.get(stringBuilder4.toString()));
                    }
                }
                edit.putInt("auto_target", FloatingViewService.target_num);
                edit.apply();
                Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
            } else {
                FloatingViewService.target_num++;
                map = FloatingViewService.px_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("px_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                map.put(stringBuilder3.toString(), Float.valueOf(0.0f));
                map = FloatingViewService.py_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("py_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                map.put(stringBuilder3.toString(), Float.valueOf(0.0f));
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                map.put(stringBuilder3.toString(), new ViewPointerAuto(getApplicationContext()));
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map.get(stringBuilder3.toString())).setClickable(true);
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map.get(stringBuilder3.toString())).setFocusable(true);
                Map map5 = FloatingViewService.mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                map5.put(stringBuilder2.toString(), new LayoutParams(-2, -2, i2, 8, -3));
                map = FloatingViewService.mParams_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mParams_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map.get(stringBuilder3.toString())).gravity = 51;
                Log.d("targetnum -1", String.valueOf(FloatingViewService.target_num - 1));
                Log.d("px_array.get(target_num-1)", String.valueOf(arrayList3.get(FloatingViewService.target_num - 1)));
                map = FloatingViewService.mParams_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mParams_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map.get(stringBuilder3.toString())).x = ((Integer) arrayList3.get(FloatingViewService.target_num - 1)).intValue();
                map = FloatingViewService.mParams_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mParams_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                ((LayoutParams) map.get(stringBuilder3.toString())).y = ((Integer) arrayList4.get(FloatingViewService.target_num - 1)).intValue();
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("@drawable/target");
                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                String stringBuilder8 = stringBuilder2.toString();
                Log.d("drawable uri : ", stringBuilder8);
                i6 = getResources().getIdentifier(stringBuilder8, null, getPackageName());
                Log.d("imageResource : ", String.valueOf(i6));
                map2 = FloatingViewService.mPointerView_auto;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append("mPointerView_auto");
                stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map2.get(stringBuilder4.toString())).setBackgroundResource(i6);
                map2 = FloatingViewService.mPointerView_auto;
                stringBuilder4 = new StringBuilder();
                stringBuilder4.append("mPointerView_auto");
                stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                ((ViewPointerAuto) map2.get(stringBuilder4.toString())).setOnTouchListener(new OnTouchListener() {
                    private float initialPointX;
                    private float initialPointY;
                    private int initialX;
                    private int initialY;
                    private String touch_target_num;
                    private int vectorX;
                    private int vectorY;

                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        try {
                            Map map;
                            StringBuilder stringBuilder;
                            Map map2;
                            StringBuilder stringBuilder2;
                            StringBuilder stringBuilder3;
                            Map map3;
                            StringBuilder stringBuilder4;
                            switch (motionEvent.getAction()) {
                                case 0:
                                    String resourceEntryName = view.getResources().getResourceEntryName(i6);
                                    if (resourceEntryName.length() > 7) {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    } else {
                                        this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                        Log.d("target name : ", resourceEntryName);
                                        Log.d("target sub name : ", this.touch_target_num);
                                    }
                                    Editor edit = FloatingViewService.settings.edit();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                    edit.apply();
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mParams_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                    this.initialPointX = motionEvent.getRawX();
                                    this.initialPointY = motionEvent.getRawY();
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("px_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    String stringBuilder5 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto");
                                    stringBuilder4.append(this.touch_target_num);
                                    map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("py_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    stringBuilder5 = stringBuilder3.toString();
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto");
                                    stringBuilder4.append(this.touch_target_num);
                                    map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).y));
                                    break;
                                case 1:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_up", stringBuilder2.toString());
                                    map2 = FloatingViewService.px_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("px_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    String stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                    map2 = FloatingViewService.py_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("py_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder6 = stringBuilder2.toString();
                                    map = FloatingViewService.mParams_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mParams_auto");
                                    stringBuilder.append(this.touch_target_num);
                                    map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                    int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    int rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                        Intent intent = new Intent(Configuration.this.getApplicationContext(), DelayActivity.class);
                                        intent.setFlags(268435456);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("target_number", this.touch_target_num);
                                        intent.putExtras(bundle);
                                        Configuration.this.startActivity(intent);
                                        break;
                                    }
                                case 2:
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(this.touch_target_num);
                                    stringBuilder2.append(" ");
                                    stringBuilder2.append(this.touch_target_num);
                                    Log.d("action_move", stringBuilder2.toString());
                                    this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                    this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                    map2 = FloatingViewService.mParams_auto;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mParams_auto");
                                    stringBuilder3.append(this.touch_target_num);
                                    ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                    WindowManager windowManager = Configuration.this.mWindowManager;
                                    Map map4 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(this.touch_target_num);
                                    View view2 = (View) map4.get(stringBuilder2.toString());
                                    map3 = FloatingViewService.mParams_auto;
                                    stringBuilder4 = new StringBuilder();
                                    stringBuilder4.append("mParams_auto");
                                    stringBuilder4.append(this.touch_target_num);
                                    windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                    break;
                                default:
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return false;
                    }
                });
                map = FloatingViewService.mPointerView_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mPointerView_auto");
                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                if (map.get(stringBuilder3.toString()) != null) {
                    map = FloatingViewService.mPointerView_auto;
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("mPointerView_auto");
                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                    if (!((ViewPointerAuto) map.get(stringBuilder3.toString())).isShown()) {
                        WindowManager windowManager2 = this.mWindowManager;
                        map2 = FloatingViewService.mPointerView_auto;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointerView_auto");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        View view2 = (View) map2.get(stringBuilder4.toString());
                        Map map6 = FloatingViewService.mParams_auto;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mParams_auto");
                        stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                        windowManager2.addView(view2, (ViewGroup.LayoutParams) map6.get(stringBuilder.toString()));
                    }
                }
                edit.putInt("auto_target", FloatingViewService.target_num);
                edit.apply();
                Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
                i5 = i4;
            }
            i3 = 1;
            i4 = i5 + 1;
        }
    }

    private void remvoe_PointerViewAll() {
        Editor edit = FloatingViewService.settings.edit();
        while (true) {
            int i = 0;
            if (FloatingViewService.target_num == 0 || FloatingViewService.mPointerView_auto == null) {
            } else {
                FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                Log.d("remove_btn  target_num : ", String.valueOf(FloatingViewService.target_num));
                int i2 = 0;
                while (i < FloatingViewService.swipe_target.size()) {
                    if (FloatingViewService.target_num == ((Integer) FloatingViewService.swipe_target.get(i)).intValue()) {
                        Log.d("FloatingViewService.swipe_target.get(i) : ", String.valueOf(FloatingViewService.swipe_target.get(i)));
                        FloatingViewService.swipe_target.remove(i);
                        FloatingViewService.swipe_target.remove(i - 1);
                        i2 = 1;
                    }
                    i++;
                }
                Map map;
                StringBuilder stringBuilder;
                WindowManager windowManager;
                Map map2;
                StringBuilder stringBuilder2;
                if (i2 != 0) {
                    map = FloatingViewService.mPointerView_auto;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointerView_auto");
                    stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                    if (map.get(stringBuilder.toString()) != null) {
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                        if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                            windowManager = this.mWindowManager;
                            map2 = FloatingViewService.mPointerView_auto;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto");
                            stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                            windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                            windowManager = this.mWindowManager;
                            map2 = FloatingViewService.mPointerView_auto_swipe;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto_s");
                            stringBuilder2.append(String.valueOf(FloatingViewService.target_num - 1));
                            windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                            edit.putInt("auto_target", FloatingViewService.target_num - 1);
                            edit.apply();
                            FloatingViewService.target_num--;
                            Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                        }
                    }
                    map = FloatingViewService.mPointerView_auto;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointerView_auto");
                    stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                    if (map.get(stringBuilder.toString()) != null) {
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                        if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                            windowManager = this.mWindowManager;
                            map2 = FloatingViewService.mPointerView_auto;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto");
                            stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                            windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                            edit.putInt("auto_target", FloatingViewService.target_num - 1);
                            edit.apply();
                            FloatingViewService.target_num--;
                            Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                        }
                    }
                } else {
                    map = FloatingViewService.mPointerView_auto;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointerView_auto");
                    stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                    if (map.get(stringBuilder.toString()) != null) {
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                        if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                            windowManager = this.mWindowManager;
                            map2 = FloatingViewService.mPointerView_auto;
                            stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto");
                            stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                            windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                            edit.putInt("auto_target", FloatingViewService.target_num - 1);
                            edit.apply();
                            FloatingViewService.target_num--;
                            Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                        }
                    }
                }
            }
        }
        for (int i3 = 0; i3 < FloatingViewService.swipe_target.size(); i3++) {
            FloatingViewService.swipe_target.remove(i3);
        }
        edit.putInt("auto_target", 0);
        edit.apply();
        FloatingViewService.target_num = 0;
        FloatingViewService.mPointerView_auto = null;
        FloatingViewService.mPointerView_auto_swipe = null;
        FloatingViewService.mParams_auto = null;
        FloatingViewService.mPointerView_auto = new HashMap();
        FloatingViewService.mPointerView_auto_swipe = new HashMap();
        FloatingViewService.mParams_auto = new HashMap();
    }

    private void launchMarket() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.auto.easytouchpropro")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    private void launchMarket2() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.dual.screen")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
