package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import java.util.ArrayList;

public class AutoSwipeSpeed extends Activity {
    static Context context;
    public static double duration_time;
    private EditText Duration_Edt;
    private Button Reset_Btn;
    Bitmap bitmap;
    Button button;
    Canvas canvas;
    private int[] loc;
    public WindowManager mWindowManager;
    Paint paint;
    Path path2;
    RelativeLayout relativeLayout;
    View view;

    public class DrawingClass {
        Paint DrawingClassPaint;
        Path DrawingClassPath;

        public Path getPath() {
            return this.DrawingClassPath;
        }

        public void setPath(Path path) {
            this.DrawingClassPath = path;
        }

        public Paint getPaint() {
            return this.DrawingClassPaint;
        }

        public void setPaint(Paint paint) {
            this.DrawingClassPaint = paint;
        }
    }

    class SketchSheetView extends View {
        public ArrayList<DrawingClass> DrawingClassArrayList = new ArrayList();

        public SketchSheetView(Context context) {
            super(context);
            AutoSwipeSpeed.this.bitmap = Bitmap.createBitmap(820, 480, Config.ARGB_4444);
            AutoSwipeSpeed.this.canvas = new Canvas(AutoSwipeSpeed.this.bitmap);
            setBackgroundColor(-1);
        }

        public boolean onTouchEvent(MotionEvent motionEvent) {
            DrawingClass drawingClass = new DrawingClass();
            AutoSwipeSpeed.this.canvas.drawPath(AutoSwipeSpeed.this.path2, AutoSwipeSpeed.this.paint);
            if (motionEvent.getAction() == 0) {
                AutoSwipeSpeed.this.path2.moveTo(motionEvent.getX(), motionEvent.getY());
                AutoSwipeSpeed.this.path2.lineTo(motionEvent.getX(), motionEvent.getY());
            } else if (motionEvent.getAction() == 2) {
                AutoSwipeSpeed.this.path2.lineTo(motionEvent.getX(), motionEvent.getY());
                drawingClass.setPath(AutoSwipeSpeed.this.path2);
                drawingClass.setPaint(AutoSwipeSpeed.this.paint);
                this.DrawingClassArrayList.add(drawingClass);
            }
            invalidate();
            return true;
        }

        public void remove_DrawingClassArrayList() {
            this.DrawingClassArrayList = null;
        }

        /* Access modifiers changed, original: protected */
        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (this.DrawingClassArrayList.size() > 0) {
                canvas.drawPath(((DrawingClass) this.DrawingClassArrayList.get(this.DrawingClassArrayList.size() - 1)).getPath(), ((DrawingClass) this.DrawingClassArrayList.get(this.DrawingClassArrayList.size() - 1)).getPaint());
            }
        }
    }

    public AutoSwipeSpeed() {
        this.loc = new int[2];
    }

    public AutoSwipeSpeed(Context context) {
        this.loc = new int[2];
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_autoswipespeed);
        if (FloatingViewService.mTracker != null) {
            FloatingViewService.mTracker.setScreenName("AutoSwipeSpeed");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        }
        widget();
    }

    /* Access modifiers changed, original: 0000 */
    public double ParseDouble(String str) {
        if (str == null || str.length() <= 0) {
            return 0.0d;
        }
        try {
            return Double.parseDouble(str);
        } catch (Exception unused) {
            return -1.0d;
        }
    }

    /* Access modifiers changed, original: 0000 */
    public int ParseInt(String str) {
        if (str == null || str.length() <= 0) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception unused) {
            return -1;
        }
    }

    private void widget() {
        this.relativeLayout = (RelativeLayout) findViewById(R.id.relativelayout1);
        this.button = (Button) findViewById(R.id.button);
        this.view = new SketchSheetView(this);
        this.paint = new Paint();
        this.path2 = new Path();
        this.relativeLayout.addView(this.view, new LayoutParams(-1, -1));
        this.paint.setDither(true);
        this.paint.setColor(Color.parseColor("#FFD700"));
        this.paint.setStyle(Style.STROKE);
        this.paint.setStrokeJoin(Join.ROUND);
        this.paint.setStrokeCap(Cap.ROUND);
        this.paint.setStrokeWidth(10.0f);
        this.button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                AutoSwipeSpeed.this.relativeLayout = (RelativeLayout) AutoSwipeSpeed.this.findViewById(R.id.relativelayout1);
                AutoSwipeSpeed.this.view = new SketchSheetView(AutoSwipeSpeed.this);
                AutoSwipeSpeed.this.paint = new Paint();
                AutoSwipeSpeed.this.path2 = new Path();
                AutoSwipeSpeed.this.relativeLayout.addView(AutoSwipeSpeed.this.view, new LayoutParams(-1, -1));
                AutoSwipeSpeed.this.paint.setDither(true);
                AutoSwipeSpeed.this.paint.setColor(Color.parseColor("#FFD700"));
                AutoSwipeSpeed.this.paint.setStyle(Style.STROKE);
                AutoSwipeSpeed.this.paint.setStrokeJoin(Join.ROUND);
                AutoSwipeSpeed.this.paint.setStrokeCap(Cap.ROUND);
                AutoSwipeSpeed.this.paint.setStrokeWidth(10.0f);
            }
        });
        this.Duration_Edt = (EditText) findViewById(R.id.swipe_duration_edt);
        this.Duration_Edt.setText(String.valueOf(FloatingViewService.settings.getInt("swipe_duration", 300)));
        AutoClickSpeed.swipe_duration_time = (double) FloatingViewService.settings.getInt("swipe_duration", 300);
        this.Duration_Edt.setSelection(this.Duration_Edt.getText().length());
        this.Duration_Edt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                Editor edit;
                if (AutoSwipeSpeed.this.ParseDouble(AutoSwipeSpeed.this.Duration_Edt.getText().toString()) > 0.0d && AutoSwipeSpeed.this.ParseDouble(AutoSwipeSpeed.this.Duration_Edt.getText().toString()) < 1000000.0d) {
                    AutoClickSpeed.swipe_duration_time = Double.parseDouble(AutoSwipeSpeed.this.Duration_Edt.getText().toString());
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("swipe_duration", Integer.parseInt(AutoSwipeSpeed.this.Duration_Edt.getText().toString()));
                    edit.apply();
                } else if (AutoSwipeSpeed.this.ParseDouble(AutoSwipeSpeed.this.Duration_Edt.getText().toString()) > 1000000.0d) {
                    AutoSwipeSpeed.this.Duration_Edt.setText("1000000");
                    AutoClickSpeed.swipe_duration_time = 1000000.0d;
                    edit = FloatingViewService.settings.edit();
                    edit.putInt("swipe_duration", 1000000);
                    edit.apply();
                    Toast.makeText(AutoSwipeSpeed.this.getApplicationContext(), "Max swipe duration seconds : 1000000 ", 0).show();
                } else {
                    AutoClickSpeed.swipe_duration_time = 300.0d;
                    Editor edit2 = FloatingViewService.settings.edit();
                    edit2.putInt("swipe_duration", 300);
                    edit2.apply();
                }
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
