package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.TextView;
import android.widget.Toast;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import java.util.Random;

public class Instruction extends Activity {
    static final String APP_ID = "app7d709ad5a8de453ab9";
    static final String ZONE_ID = "vzaa9ab877d6604a38bd";
    public static boolean auto_flag;
    public static boolean back_flag;
    static Context context;
    static Drawable currDrawable1;
    static Drawable currDrawable2;
    static Drawable currDrawable3;
    static Drawable currDrawable4;
    static Drawable currDrawable5;
    public static ProgressDialog mDialog;
    public static boolean quick_flag;
    public static boolean task_flag;
    private TextView P_Alpha_100;
    private TextView P_Alpha_20;
    private TextView P_Alpha_40;
    private TextView P_Alpha_60;
    private TextView P_Alpha_80;
    private ScrollView Rl;
    private TextView a1;
    private TextView a2;
    private TextView a3;
    private View adContainer;
    private ImageView banner;
    Handler handler;
    private LayoutInflater inflater;
    private boolean loadingAd_flag;
    private int[] loc;
    private RelativeLayout mAssistiveView;
    private ShareActionProvider mShareActionProvider;
    public WindowManager mWindowManager;
    private ImageView pbanner;
    Runnable runnable;
    private int startCnt;
    private int style_num;
    private int style_type;
    private OnClickListener yesListener;

    public Instruction() {
        this.loc = new int[2];
        this.yesListener = new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Instruction.this.launchMarket();
            }
        };
    }

    public Instruction(Context context) {
        this.loc = new int[2];
        this.yesListener = /* anonymous class already generated */;
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_instructions);
        this.loadingAd_flag = true;
        if (FloatingViewService.mTracker != null) {
            FloatingViewService.mTracker.setScreenName("Instruction");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        }
        getActionBar();
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mAssistiveView = (RelativeLayout) this.inflater.inflate(R.layout.activity_setting, null);
        this.mWindowManager = (WindowManager) getSystemService("window");
        widget();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return false;
        }
        onBackPressed();
        return true;
    }

    private boolean isMyServiceRunning(Class<?> cls) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        this.mShareActionProvider = (ShareActionProvider) menu.findItem(R.id.shareButton).getActionProvider();
        this.mShareActionProvider.setShareIntent(doShare());
        return true;
    }

    public Intent doShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Easy Touch & Assistive Touch & On-Screen-Pointer");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nLet me recommend you this application\n\n");
        stringBuilder.append("https://play.google.com/store/apps/details?id=com.auto.easytouch \n\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        return intent;
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        this.loadingAd_flag = false;
    }

    /* Access modifiers changed, original: protected */
    public void onPause() {
        super.onPause();
    }

    public boolean getRandomBoolean() {
        return new Random().nextBoolean();
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
    }

    private void widget() {
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
    }

    private void launchMarket() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.auto.easytouchpropro")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    private void launchMarket2() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.dual.screen")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
