package com.autoclicker.autoswiper.servicecontrol;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.ShareActionProvider;
import android.widget.ShareActionProvider.OnShareTargetSelectedListener;
import android.widget.TextView;
import android.widget.Toast;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.Purchase.PurchasesResult;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsParams.Builder;
import com.autoclicker.autoswiper.AnalyticsApplication;
import com.autoclicker.autoswiper.BuildConfig;
import com.autoclicker.autoswiper.FloatingViewService;
import com.autoclicker.autoswiper.R;
import com.autoclicker.autoswiper.billing.BillingConstants;
import com.autoclicker.autoswiper.billing.BillingManager;
import com.autoclicker.autoswiper.billing.BillingManager.BillingUpdatesListener;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import com.google.android.gms.analytics.Tracker;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AllSettings extends Activity implements PurchasesUpdatedListener {
    public static TextView ClickTimes = null;
    public static final String TAG = "BillingManager";
    public static boolean auto_flag;
    public static boolean back_flag;
    static Context context;
    static Drawable currDrawable1;
    static Drawable currDrawable2;
    static Drawable currDrawable3;
    static Drawable currDrawable4;
    static Drawable currDrawable5;
    public static boolean quick_flag;
    private static long startTime1;
    private static long startTime2;
    private static long startTime3;
    private static long startTime4;
    private static long startTime5;
    public static boolean task_flag;
    private Button AutoClickSpeed;
    private Button AutoSwipeSpeed;
    private Button Config;
    private Button Instruction;
    private Button MoreApps;
    private Button Pro;
    private int SMART_BANNERNum = 1;
    private int SMART_BANNER_change = 0;
    private Button VoiceRecog;
    Activity activity;
    private boolean afterAd = false;
    private Button buttonEventTab;
    private Button buttonRequestPlacement;
    private Button buttonShowPlacement;
    private Button buttonUserTab;
    ConsumeResponseListener consumeListener = new ConsumeResponseListener() {
        public void onConsumeResponse(int i, String str) {
        }
    };
    private Button currentButton;
    private View decorView;
    private String displayText = BuildConfig.FLAVOR;
    private Button getCurrencyBalanceButton;
    private Button getDirectPlayVideoAd;
    Handler handler;
    private LayoutInflater inflater;
    private boolean loadingAd_flag;
    private RelativeLayout mAssistiveView;
    private BillingClient mBillingClient;
    private BillingManager mBillingManager;
    private Handler mHandler1;
    private Handler mHandler2;
    private Handler mHandler3;
    private Handler mHandler4;
    private Handler mHandler5;
    private ShareActionProvider mShareActionProvider;
    private Runnable mUpdateTimeTask1;
    private Runnable mUpdateTimeTask2;
    private Runnable mUpdateTimeTask3;
    private Runnable mUpdateTimeTask4;
    private Runnable mUpdateTimeTask5;
    public WindowManager mWindowManager;
    private ScrollView mainScrollView;
    private TextView outputTextView;
    private ImageView pSMART_BANNER;
    private EditText placementNameInput;
    private HashMap<String, Object> properties;
    Purchase purchase;
    PurchasesResult purchasesResult;
    private RelativeLayout rl;
    Runnable runnable;
    private boolean share_flag = false;
    Builder skuDetailsParams;
    private int startCnt;
    private int style_num;
    private int style_type;
    private OnClickListener yesListener = new OnClickListener() {
        public void onClick(DialogInterface dialogInterface, int i) {
            AllSettings.this.launchMarket();
        }
    };

    private void handlePurchase(Purchase purchase) {
    }

    private void widget() {
    }

    public AllSettings(Context context) {
        context = context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_setting);
        this.activity = this;
        widget();
        FloatingViewService.mTracker = ((AnalyticsApplication) getApplication()).getDefaultTracker();
        FloatingViewService.mTracker.setScreenName("Automatic Clicker - AllSettings");
        FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
        this.mBillingManager = new BillingManager(this, new BillingUpdatesListener() {
            public void onBillingClientSetupFinished() {
            }

            public void onConsumeFinished(String str, int i) {
            }

            public void onPurchasesUpdated(List<Purchase> list) {
            }
        });
        final ScrollView scrollView = (ScrollView) findViewById(R.id.scrollView);
        scrollView.post(new Runnable() {
            public void run() {
                scrollView.scrollTo(0, 0);
            }
        });
        this.AutoClickSpeed = (Button) findViewById(R.id.autoclick_btn);
        this.AutoClickSpeed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d("Pointer Button", "clicked");
                AllSettings.this.startActivity(new Intent(AllSettings.this, AutoClickSpeed.class));
            }
        });
        this.AutoSwipeSpeed = (Button) findViewById(R.id.swipespeed_btn);
        this.AutoSwipeSpeed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d("Pointer Button", "clicked");
                AllSettings.this.startActivity(new Intent(AllSettings.this, AutoSwipeSpeed.class));
            }
        });
        this.Instruction = (Button) findViewById(R.id.instruction_btn);
        this.Instruction.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d("Pointer Button", "clicked");
                AllSettings.this.startActivity(new Intent(AllSettings.this, Instruction.class));
            }
        });
        this.Config = (Button) findViewById(R.id.save_btn);
        this.Config.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AllSettings.this.startActivity(new Intent(AllSettings.this, Configuration.class));
            }
        });
        this.Pro = (Button) findViewById(R.id.buy_btn);
        try {
            this.mBillingClient = BillingClient.newBuilder(this).setListener(this).build();
            this.mBillingClient.startConnection(new BillingClientStateListener() {
                public void onBillingSetupFinished(int i) {
                    if (i == 0) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(BillingConstants.SKU_PREMIUM);
                        AllSettings.this.skuDetailsParams = SkuDetailsParams.newBuilder();
                        AllSettings.this.skuDetailsParams.setSkusList(arrayList).setType("inapp");
                        AllSettings.this.mBillingClient.querySkuDetailsAsync(AllSettings.this.skuDetailsParams.build(), new AllSettings$7$$Lambda$0(this));
                        AllSettings.this.mBillingClient.queryPurchaseHistoryAsync("inapp", new PurchaseHistoryResponseListener() {
                            public void onPurchaseHistoryResponse(int i, List<Purchase> list) {
                            }
                        });
                        AllSettings.this.mBillingManager.queryPurchases();
                        if (FloatingViewService.purchased) {
                            Log.d("FloatingViewService.purchased == true : ", "true");
                            AllSettings.this.Pro.setVisibility(8);
                            FloatingViewService.target_limit = 48;
                        }
                    }
                }

                /* Access modifiers changed, original: final|synthetic */
                public final /* synthetic */ void lambda$onBillingSetupFinished$0$AllSettings$7(int i, final List list) {
                    if (i == 0 && list != null) {
                        for (SkuDetails skuDetails : list) {
                            skuDetails.getSku();
                            skuDetails.getPrice();
                            Log.d("sku : ", String.valueOf(skuDetails.getSku()));
                            Log.d("price : ", String.valueOf(skuDetails.getPrice()));
                        }
                        Log.d("skuDetailsList.Size() : ", String.valueOf(list.size()));
                        AllSettings.this.Pro.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                FloatingViewService.mTracker.setScreenName("Automatic Clicker Remove Ads");
                                FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
                                AllSettings.this.mBillingClient.launchBillingFlow(AllSettings.this.activity, BillingFlowParams.newBuilder().setSkuDetails((SkuDetails) list.get(0)).build());
                            }
                        });
                    }
                }

                public void onBillingServiceDisconnected() {
                    Toast.makeText(AllSettings.this.getApplicationContext(), "Check your connection", 0).show();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        FloatingViewService.settings = PreferenceManager.getDefaultSharedPreferences(this);
        this.startCnt = FloatingViewService.settings.getInt("start_cnt", 0) + 1;
        Editor edit = FloatingViewService.settings.edit();
        edit.putInt("start_cnt", this.startCnt);
        edit.apply();
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        this.mWindowManager = (WindowManager) getSystemService("window");
    }

    private void launchMarket() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.autoclicker.autoswiper")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    private void launchMarket2() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.auto.clicker.tapper5")));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, " unable to find market app", 1).show();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        this.mShareActionProvider = (ShareActionProvider) menu.findItem(R.id.shareButton).getActionProvider();
        this.mShareActionProvider.setShareIntent(doShare());
        this.mShareActionProvider.setOnShareTargetSelectedListener(new OnShareTargetSelectedListener() {
            public boolean onShareTargetSelected(ShareActionProvider shareActionProvider, Intent intent) {
                String networkCountryIso = ((TelephonyManager) AllSettings.this.getSystemService("phone")).getNetworkCountryIso();
                Tracker tracker = FloatingViewService.mTracker;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("doShare clicked - ");
                stringBuilder.append(networkCountryIso);
                tracker.setScreenName(stringBuilder.toString());
                FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
                FloatingViewService.rate_flag = true;
                Log.d("do share", "clicked");
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    public Intent doShare() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", "Auto Clicker - Super Fast");
        String string = getResources().getString(R.string.recommend_app);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append("https://play.google.com/store/apps/details?id=com.autoclicker.autoswiper \n\n");
        intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
        return intent;
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Destroying helper.");
        if (this.mBillingManager != null) {
            this.mBillingManager.destroy();
        }
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (this.mBillingManager != null && this.mBillingManager.getBillingClientResponseCode() == 0) {
            this.mBillingManager.queryPurchases();
        }
        if (FloatingViewService.purchased) {
            Log.d("FloatingViewService.purchased == true : ", "true");
            this.Pro.setVisibility(8);
            findViewById(R.id.buy_info).setVisibility(8);
            findViewById(R.id.buy_info2).setVisibility(8);
        }
        FloatingViewService.settings = PreferenceManager.getDefaultSharedPreferences(this);
        this.startCnt = FloatingViewService.settings.getInt("start_cnt", 0) + 1;
        Editor edit = FloatingViewService.settings.edit();
        edit.putInt("start_cnt", this.startCnt);
        edit.apply();
        Log.d("startCnt : ", String.valueOf(this.startCnt));
        if (this.startCnt % 7 == 1) {
            FloatingViewService.rate_flag = true;
        }
        if (FloatingViewService.rate_flag && !FloatingViewService.settings.getBoolean("rate", false)) {
            FloatingViewService.rate_flag = false;
            startActivity(new Intent(this, RateActivity.class));
        }
    }

    /* Access modifiers changed, original: protected */
    public void onPause() {
        super.onPause();
    }

    public void onPurchasesUpdated(int i, @Nullable List<Purchase> list) {
        Log.d("onPurchased : ", String.valueOf(i));
        if (i == 0 && list != null) {
            try {
                for (Purchase handlePurchase : list) {
                    handlePurchase(handlePurchase);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (i == 1) {
            FloatingViewService.mTracker.setScreenName("Automatic Clicker Remove Ads user cancelled");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.purchase_cancelled), 0).show();
        } else if (i == 7) {
            FloatingViewService.mTracker.setScreenName("Automatic Clicker Remove Ads item_already_owned");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.already_purchased), 0).show();
        } else {
            FloatingViewService.mTracker.setScreenName("Automatic Clicker Remove Ads please_try_again_later");
            FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.please_try_again_later), 0).show();
        }
    }
}
