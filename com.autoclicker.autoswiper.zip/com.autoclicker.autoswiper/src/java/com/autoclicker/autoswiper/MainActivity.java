package com.autoclicker.autoswiper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import com.autoclicker.autoswiper.billing.BillingManager;
import com.autoclicker.autoswiper.service.AutoClicker;
import com.autoclicker.autoswiper.servicecontrol.AllSettings;

public class MainActivity extends Activity {
    public static Context main_context;
    private Button Btn_Access;
    private Button Btn_Overlay;
    private LinearLayout Lyt_Access;
    private LinearLayout Lyt_Overlay;
    private LayoutInflater inflater;
    private BillingManager mBillingManager;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_pref);
        main_context = this;
        getWindow().setFlags(2097152, 1024);
        this.inflater = (LayoutInflater) getSystemService("layout_inflater");
        widget();
    }

    private void widget() {
        this.Lyt_Overlay = (LinearLayout) findViewById(R.id.overlay_pref);
        this.Lyt_Access = (LinearLayout) findViewById(R.id.access_pref);
        this.Btn_Overlay = (Button) findViewById(R.id.allow_overlay);
        this.Btn_Overlay.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("package:");
                stringBuilder.append(MainActivity.this.getPackageName());
                MainActivity.this.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse(stringBuilder.toString())));
            }
        });
        this.Btn_Access = (Button) findViewById(R.id.allow_access);
        this.Btn_Access.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
                intent.addFlags(268435456);
                MainActivity.this.startActivity(intent);
            }
        });
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        if (this.mBillingManager != null && this.mBillingManager.getBillingClientResponseCode() == 0) {
            this.mBillingManager.queryPurchases();
        }
        if (Settings.canDrawOverlays(this) && AutoClicker.instance != null) {
            startActivity(new Intent(this, AllSettings.class));
            startService(new Intent(this, FloatingViewService.class));
            finish();
        } else if (!Settings.canDrawOverlays(this) && AutoClicker.instance == null) {
        } else {
            if (Settings.canDrawOverlays(this) && AutoClicker.instance == null) {
                this.Lyt_Overlay.setVisibility(8);
            } else if (!Settings.canDrawOverlays(this) && AutoClicker.instance != null) {
                this.Lyt_Access.setVisibility(8);
            }
        }
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(this, MainActivity.class));
    }

    /* Access modifiers changed, original: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("resultCode ");
        stringBuilder.append(i2);
        Log.i("TAG", stringBuilder.toString());
        if (i == 1234) {
            this.Lyt_Overlay.setVisibility(8);
            if (AutoClicker.instance != null) {
                startActivity(new Intent(this, AllSettings.class));
                startService(new Intent(this, FloatingViewService.class));
                finish();
            }
        }
        super.onActivityResult(i, i2, intent);
    }
}
