package com.autoclicker.autoswiper.swipe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public class DrawView extends View {
    Paint paint = new Paint();
    int x1;
    int x2;
    int y1;
    int y2;

    public void assign(int i, int i2, int i3, int i4) {
        this.x1 = i;
        this.y1 = i2;
        this.x2 = i3;
        this.y2 = i4;
    }

    public DrawView(Context context) {
        super(context);
        this.paint.setColor(-16711936);
        this.paint.setStrokeWidth(50.0f);
    }

    public void onDraw(Canvas canvas) {
        canvas.drawLine((float) this.x1, (float) this.y1, (float) this.x2, (float) this.y2, this.paint);
    }
}
