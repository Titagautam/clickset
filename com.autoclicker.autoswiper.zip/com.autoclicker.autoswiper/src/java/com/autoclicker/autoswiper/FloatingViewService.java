package com.autoclicker.autoswiper;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.Toast;
import com.autoclicker.autoswiper.service.AutoClicker;
import com.autoclicker.autoswiper.servicecontrol.AllSettings;
import com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed;
import com.autoclicker.autoswiper.servicecontrol.DelayActivity;
import com.autoclicker.autoswiper.swipe.DrawView;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders.ScreenViewBuilder;
import com.google.android.gms.analytics.Tracker;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FloatingViewService extends Service {
    public static boolean adding = true;
    public static boolean auto_click = false;
    public static View collapsedView = null;
    public static int deviceHeight = 0;
    public static int deviceHorizontalCenter = 0;
    public static int deviceVerticalCenter = 0;
    public static int deviceWidth = 0;
    public static Display display = null;
    public static View expandedView = null;
    public static int expanded_shape = 0;
    public static View mFloatingView = null;
    public static LayoutParams mParams = null;
    public static LayoutParams mParams2 = null;
    public static Map<String, LayoutParams> mParams_auto = null;
    public static Map<String, ViewPointerAuto> mPointerView_auto = null;
    public static Map<String, ViewPointerAutoSwipe> mPointerView_auto_swipe = null;
    public static BroadcastReceiver mReceiver = null;
    public static Tracker mTracker = null;
    public static Map<String, OnTouchListener> mViewTouchListener_auto = null;
    public static ArrayList<OnTouchListener> mViewtouchListener_array = new ArrayList();
    public static WindowManager mWindowManager = null;
    public static int move_flag = 1;
    public static LayoutParams params = null;
    public static float pointer_flag = 0.0f;
    public static int purchase_num = 20;
    public static boolean purchased = false;
    public static float px = 0.0f;
    public static Map<String, Float> px_auto = null;
    public static float py = 0.0f;
    public static Map<String, Float> py_auto = null;
    public static boolean rate_flag = false;
    public static boolean scroll_flag = false;
    public static SharedPreferences settings = null;
    public static ImageView share = null;
    public static float speed = 0.0f;
    public static ArrayList<Integer> swipe_target = new ArrayList();
    public static int target_cnt = 1;
    public static int target_limit = 48;
    public static int target_num = 0;
    public static int target_rotation = 1;
    public static int times;
    public static boolean touch_first;
    public static View touchpadView;
    DrawView drawView;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public synchronized Tracker getDefaultTracker() {
        if (mTracker == null) {
            mTracker = GoogleAnalytics.getInstance(this).newTracker(R.xml.global_tracker);
        }
        return mTracker;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        try {
            switch (((WindowManager) getSystemService("window")).getDefaultDisplay().getRotation()) {
                case 0:
                    System.out.println("SCREEN_ORIENTATION_PORTRAIT");
                    params.gravity = 51;
                    break;
                case 1:
                    System.out.println("SCREEN_ORIENTATION_LANDSCAPE");
                    params.gravity = 51;
                    break;
                case 2:
                    System.out.println("SCREEN_ORIENTATION_REVERSE_PORTRAIT");
                    params.gravity = 85;
                    break;
                case 3:
                    System.out.println("SCREEN_ORIENTATION_REVERSE_LANDSCAPE");
                    params.gravity = 51;
                    break;
                default:
                    break;
            }
            displayMetrics2();
            params.softInputMode = 16;
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void onCreate() {
        super.onCreate();
        mTracker = ((AnalyticsApplication) getApplication()).getDefaultTracker();
        IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_OFF");
        mReceiver = new ScreenReceiver();
        registerReceiver(mReceiver, intentFilter);
        mWindowManager = (WindowManager) getSystemService("window");
        display = ((WindowManager) getSystemService("window")).getDefaultDisplay();
        mFloatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null);
        int i = 2038;
        final int i2 = VERSION.SDK_INT >= 26 ? 2038 : 2003;
        if (VERSION.SDK_INT < 26) {
            i = 2006;
        }
        params = new LayoutParams(-2, -2, i2, 8, -3);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;
        mWindowManager.addView(mFloatingView, params);
        mPointerView_auto = new HashMap();
        mPointerView_auto_swipe = new HashMap();
        mParams_auto = new HashMap();
        mViewTouchListener_auto = new HashMap();
        px_auto = new HashMap();
        py_auto = new HashMap();
        try {
            displayMetrics2();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        settings = PreferenceManager.getDefaultSharedPreferences(this);
        Editor edit = settings.edit();
        edit.putInt("auto_target", 0);
        edit.apply();
        target_num = 0;
        AutoClickSpeed.clickpersecond = settings.getInt("clickpersecond", 30);
        AutoClickSpeed.duration_time = ((double) settings.getInt("duration", -1)) * 1000.0d;
        AutoClickSpeed.swipe_duration_time = (double) settings.getInt("swipe_duration", 300);
        expanded_shape = settings.getInt("expanded_shape", 1);
        purchased = settings.getBoolean("purchased", false);
        if (purchased) {
            purchase_num = 48;
        }
        if (expanded_shape == 1) {
            expandedView = mFloatingView.findViewById(R.id.expanded_container);
            collapsedView = mFloatingView.findViewById(R.id.collapse_view);
        } else if (expanded_shape == 2) {
            expandedView = mFloatingView.findViewById(R.id.vexpanded_container);
            collapsedView = mFloatingView.findViewById(R.id.collapse_view);
        }
        ((ImageView) mFloatingView.findViewById(R.id.close_btn)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    for (int i = 1; i <= FloatingViewService.mPointerView_auto.size(); i++) {
                        Map map = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(i);
                        if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                            WindowManager windowManager = FloatingViewService.mWindowManager;
                            Map map2 = FloatingViewService.mPointerView_auto;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto");
                            stringBuilder2.append(i);
                            windowManager.removeViewImmediate((View) map2.get(stringBuilder2.toString()));
                        }
                    }
                    FloatingViewService.this.stopSelf();
                }
            }
        });
        ((ImageView) mFloatingView.findViewById(R.id.add_swipe)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    Editor edit = FloatingViewService.settings.edit();
                    FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                    stringBuilder.append(" | ");
                    stringBuilder.append(String.valueOf(FloatingViewService.purchase_num));
                    Log.d("target_num | purchase_num", stringBuilder.toString());
                    if (FloatingViewService.target_num < FloatingViewService.purchase_num) {
                        FloatingViewService.target_num++;
                        FloatingViewService.swipe_target.add(Integer.valueOf(FloatingViewService.target_num));
                        if (FloatingViewService.mPointerView_auto == null) {
                            FloatingViewService.mPointerView_auto = new HashMap();
                        }
                        if (FloatingViewService.mPointerView_auto_swipe == null) {
                            FloatingViewService.mPointerView_auto_swipe = new HashMap();
                        }
                        Map map = FloatingViewService.px_auto;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("px_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.py_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("py_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), new ViewPointerAuto(FloatingViewService.this.getApplicationContext()));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder2.toString())).setClickable(true);
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder2.toString())).setFocusable(true);
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), new LayoutParams(-2, -2, i2, 8, -3));
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder2.toString())).gravity = 51;
                        map = FloatingViewService.mParams_auto;
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mParams_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder3.toString())).x = FloatingViewService.deviceHorizontalCenter - 50;
                        map = FloatingViewService.mParams_auto;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mParams_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder3.toString())).y = FloatingViewService.deviceVerticalCenter - 50;
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("@drawable/sarget");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        final int identifier = FloatingViewService.this.getResources().getIdentifier(stringBuilder4.toString(), null, FloatingViewService.this.getPackageName());
                        Map map2 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map2.get(stringBuilder5.toString())).setBackgroundResource(identifier);
                        map2 = FloatingViewService.px_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("px_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        map2.put(stringBuilder5.toString(), Float.valueOf(0.0f));
                        map2 = FloatingViewService.py_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("py_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        map2.put(stringBuilder5.toString(), Float.valueOf(0.0f));
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        map2.put(stringBuilder5.toString(), new ViewPointerAutoSwipe(FloatingViewService.this.getApplicationContext()));
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAutoSwipe) map2.get(stringBuilder5.toString())).setClickable(true);
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAutoSwipe) map2.get(stringBuilder5.toString())).setFocusable(true);
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mParams_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        String stringBuilder6 = stringBuilder5.toString();
                        LayoutParams layoutParams = r10;
                        LayoutParams layoutParams2 = new LayoutParams(-1, -1, i, 262200, -3);
                        map2.put(stringBuilder6, layoutParams);
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mParams_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map2.get(stringBuilder5.toString())).gravity = 51;
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mParams_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map2.get(stringBuilder5.toString())).x = FloatingViewService.deviceHorizontalCenter - 50;
                        map2 = FloatingViewService.mParams_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mParams_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map2.get(stringBuilder5.toString())).y = FloatingViewService.deviceVerticalCenter + 300;
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder5.toString());
                        Map map3 = FloatingViewService.mParams_auto;
                        StringBuilder stringBuilder7 = new StringBuilder();
                        stringBuilder7.append("mParams_auto");
                        stringBuilder7.append(FloatingViewService.target_num);
                        int i = ((LayoutParams) map3.get(stringBuilder7.toString())).x;
                        Map map4 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder8 = new StringBuilder();
                        stringBuilder8.append("mPointerView_auto");
                        stringBuilder8.append(String.valueOf(FloatingViewService.target_num));
                        i += ((ViewPointerAuto) map4.get(stringBuilder8.toString())).getWidth();
                        map4 = FloatingViewService.mParams_auto;
                        stringBuilder8 = new StringBuilder();
                        stringBuilder8.append("mParams_auto");
                        stringBuilder8.append(FloatingViewService.target_num);
                        int i2 = ((LayoutParams) map4.get(stringBuilder8.toString())).y;
                        Map map5 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder9 = new StringBuilder();
                        stringBuilder9.append("mPointerView_auto");
                        stringBuilder9.append(String.valueOf(FloatingViewService.target_num));
                        i2 += ((ViewPointerAuto) map5.get(stringBuilder9.toString())).getWidth();
                        map5 = FloatingViewService.mParams_auto;
                        stringBuilder9 = new StringBuilder();
                        stringBuilder9.append("mParams_auto");
                        stringBuilder9.append(FloatingViewService.target_num);
                        int i3 = ((LayoutParams) map5.get(stringBuilder9.toString())).x;
                        Map map6 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder10 = new StringBuilder();
                        stringBuilder10.append("mPointerView_auto");
                        stringBuilder10.append(String.valueOf(FloatingViewService.target_num));
                        i3 += ((ViewPointerAuto) map6.get(stringBuilder10.toString())).getWidth();
                        map6 = FloatingViewService.mParams_auto;
                        stringBuilder10 = new StringBuilder();
                        stringBuilder10.append("mParams_auto");
                        stringBuilder10.append(FloatingViewService.target_num);
                        int i4 = ((LayoutParams) map6.get(stringBuilder10.toString())).y;
                        Map map7 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder11 = new StringBuilder();
                        stringBuilder11.append("mPointerView_auto");
                        stringBuilder11.append(String.valueOf(FloatingViewService.target_num));
                        viewPointerAutoSwipe.assign(i, i2, i3, i4 + ((ViewPointerAuto) map7.get(stringBuilder11.toString())).getWidth());
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder5.toString());
                        ViewPointerAutoSwipe.draw_flag = false;
                        WindowManager windowManager = FloatingViewService.mWindowManager;
                        map2 = FloatingViewService.mPointerView_auto_swipe;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto_s");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        View view2 = (View) map2.get(stringBuilder5.toString());
                        map3 = FloatingViewService.mParams_auto;
                        stringBuilder7 = new StringBuilder();
                        stringBuilder7.append("mParams_auto_s");
                        stringBuilder7.append(String.valueOf(FloatingViewService.target_num));
                        windowManager.addView(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder7.toString()));
                        Map map8 = FloatingViewService.mPointerView_auto;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mPointerView_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map8.get(stringBuilder3.toString())).setOnTouchListener(new OnTouchListener() {
                            private float initialPointX;
                            private float initialPointY;
                            private int initialX;
                            private int initialY;
                            private String touch_target_num;
                            private int vectorX;
                            private int vectorY;

                            public boolean onTouch(View view, MotionEvent motionEvent) {
                                try {
                                    Map map;
                                    StringBuilder stringBuilder;
                                    Map map2;
                                    StringBuilder stringBuilder2;
                                    StringBuilder stringBuilder3;
                                    Map map3;
                                    StringBuilder stringBuilder4;
                                    int rawY;
                                    WindowManager windowManager;
                                    Map map4;
                                    View view2;
                                    switch (motionEvent.getAction()) {
                                        case 0:
                                            String resourceEntryName = view.getResources().getResourceEntryName(identifier);
                                            if (resourceEntryName.length() > 7) {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            } else {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            }
                                            Editor edit = FloatingViewService.settings.edit();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                            edit.apply();
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                            this.initialPointX = motionEvent.getRawX();
                                            this.initialPointY = motionEvent.getRawY();
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("px_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            String stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("py_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).y));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).setPaint_Play();
                                            break;
                                        case 1:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_up", stringBuilder2.toString());
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("px_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            String stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("py_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                            int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                                Intent intent = new Intent(FloatingViewService.this.getApplicationContext(), DelayActivity.class);
                                                intent.setFlags(268435456);
                                                Bundle bundle = new Bundle();
                                                bundle.putString("target_number", this.touch_target_num);
                                                intent.putExtras(bundle);
                                                FloatingViewService.this.startActivity(intent);
                                            }
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).setPaint_Not_Play();
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto_s");
                                            stringBuilder2.append(this.touch_target_num);
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto_s");
                                            stringBuilder4.append(this.touch_target_num);
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            break;
                                        case 2:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_move", stringBuilder2.toString());
                                            this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder.toString()));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                            ViewPointerAutoSwipe.draw_flag = true;
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                            map4 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            rawY = ((LayoutParams) map4.get(stringBuilder2.toString())).x;
                                            map3 = FloatingViewService.mPointerView_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mPointerView_auto");
                                            stringBuilder.append(String.valueOf(this.touch_target_num));
                                            rawY += ((ViewPointerAuto) map3.get(stringBuilder.toString())).getWidth() / 2;
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            int i = ((LayoutParams) map3.get(stringBuilder.toString())).y;
                                            Map map5 = FloatingViewService.mPointerView_auto;
                                            StringBuilder stringBuilder7 = new StringBuilder();
                                            stringBuilder7.append("mPointerView_auto");
                                            stringBuilder7.append(String.valueOf(this.touch_target_num));
                                            i += ((ViewPointerAuto) map5.get(stringBuilder7.toString())).getWidth() / 2;
                                            map5 = FloatingViewService.mParams_auto;
                                            stringBuilder7 = new StringBuilder();
                                            stringBuilder7.append("mParams_auto");
                                            stringBuilder7.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() + 1));
                                            int i2 = ((LayoutParams) map5.get(stringBuilder7.toString())).x;
                                            Map map6 = FloatingViewService.mPointerView_auto;
                                            StringBuilder stringBuilder8 = new StringBuilder();
                                            stringBuilder8.append("mPointerView_auto");
                                            stringBuilder8.append(String.valueOf(this.touch_target_num));
                                            i2 += ((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth() / 2;
                                            map6 = FloatingViewService.mParams_auto;
                                            stringBuilder8 = new StringBuilder();
                                            stringBuilder8.append("mParams_auto");
                                            stringBuilder8.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() + 1));
                                            int i3 = ((LayoutParams) map6.get(stringBuilder8.toString())).y;
                                            map6 = FloatingViewService.mPointerView_auto;
                                            stringBuilder8 = new StringBuilder();
                                            stringBuilder8.append("mPointerView_auto");
                                            stringBuilder8.append(String.valueOf(this.touch_target_num));
                                            viewPointerAutoSwipe.assign(rawY, i, i2, i3 + (((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth() / 2));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto_s");
                                            stringBuilder2.append(this.touch_target_num);
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto_s");
                                            stringBuilder4.append(this.touch_target_num);
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            break;
                                        default:
                                            break;
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return false;
                            }
                        });
                        map = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mPointerView_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        if (map.get(stringBuilder12.toString()) != null) {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder12 = new StringBuilder();
                            stringBuilder12.append("mPointerView_auto");
                            stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                            if (!((ViewPointerAuto) map.get(stringBuilder12.toString())).isShown()) {
                                WindowManager windowManager2 = FloatingViewService.mWindowManager;
                                map8 = FloatingViewService.mPointerView_auto;
                                stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("mPointerView_auto");
                                stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                View view3 = (View) map8.get(stringBuilder3.toString());
                                map2 = FloatingViewService.mParams_auto;
                                stringBuilder5 = new StringBuilder();
                                stringBuilder5.append("mParams_auto");
                                stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                                windowManager2.addView(view3, (ViewGroup.LayoutParams) map2.get(stringBuilder5.toString()));
                            }
                        }
                        edit.putInt("auto_target", FloatingViewService.target_num);
                        edit.apply();
                        Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
                        FloatingViewService.target_num++;
                        FloatingViewService.swipe_target.add(Integer.valueOf(FloatingViewService.target_num));
                        if (FloatingViewService.mPointerView_auto == null) {
                            FloatingViewService.mPointerView_auto = new HashMap();
                        }
                        if (FloatingViewService.mPointerView_auto_swipe == null) {
                            FloatingViewService.mPointerView_auto_swipe = new HashMap();
                        }
                        map = FloatingViewService.px_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("px_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder12.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.py_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("py_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder12.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mPointerView_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder12.toString(), new ViewPointerAuto(FloatingViewService.this.getApplicationContext()));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mPointerView_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder12.toString())).setClickable(true);
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mPointerView_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder12.toString())).setFocusable(true);
                        map = FloatingViewService.mParams_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mParams_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder12.toString(), new LayoutParams(-2, -2, i2, 8, -3));
                        map = FloatingViewService.mParams_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mParams_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder12.toString())).gravity = 51;
                        map = FloatingViewService.mParams_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mParams_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder12.toString())).x = FloatingViewService.deviceHorizontalCenter - 50;
                        map = FloatingViewService.mParams_auto;
                        stringBuilder12 = new StringBuilder();
                        stringBuilder12.append("mParams_auto");
                        stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder12.toString())).y = FloatingViewService.deviceVerticalCenter - 50;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("@drawable/sarget");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        identifier = FloatingViewService.this.getResources().getIdentifier(stringBuilder4.toString(), null, FloatingViewService.this.getPackageName());
                        map8 = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map8.get(stringBuilder2.toString())).setBackgroundResource(identifier);
                        map8 = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map8.get(stringBuilder2.toString())).setOnTouchListener(new OnTouchListener() {
                            private float initialPointX;
                            private float initialPointY;
                            private int initialX;
                            private int initialY;
                            private String touch_target_num;
                            private int vectorX;
                            private int vectorY;

                            public boolean onTouch(View view, MotionEvent motionEvent) {
                                try {
                                    Map map;
                                    StringBuilder stringBuilder;
                                    Map map2;
                                    StringBuilder stringBuilder2;
                                    StringBuilder stringBuilder3;
                                    Map map3;
                                    StringBuilder stringBuilder4;
                                    int rawY;
                                    WindowManager windowManager;
                                    Map map4;
                                    View view2;
                                    switch (motionEvent.getAction()) {
                                        case 0:
                                            String resourceEntryName = view.getResources().getResourceEntryName(identifier);
                                            if (resourceEntryName.length() > 7) {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            } else {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            }
                                            Editor edit = FloatingViewService.settings.edit();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                            edit.apply();
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                            this.initialPointX = motionEvent.getRawX();
                                            this.initialPointY = motionEvent.getRawY();
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("px_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            String stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("py_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).y));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).setPaint_Play();
                                            break;
                                        case 1:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_up", stringBuilder2.toString());
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("px_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            String stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("py_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                            int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                                Intent intent = new Intent(FloatingViewService.this.getApplicationContext(), DelayActivity.class);
                                                intent.setFlags(268435456);
                                                Bundle bundle = new Bundle();
                                                bundle.putString("target_number", this.touch_target_num);
                                                intent.putExtras(bundle);
                                                FloatingViewService.this.startActivity(intent);
                                            }
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).setPaint_Not_Play();
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto_s");
                                            stringBuilder2.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto_s");
                                            stringBuilder4.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            break;
                                        case 2:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_move", stringBuilder2.toString());
                                            this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(this.touch_target_num));
                                            ViewPointerAutoSwipe viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                            ViewPointerAutoSwipe.draw_flag = true;
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                            viewPointerAutoSwipe = (ViewPointerAutoSwipe) map2.get(stringBuilder3.toString());
                                            map4 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            rawY = ((LayoutParams) map4.get(stringBuilder2.toString())).x;
                                            map3 = FloatingViewService.mPointerView_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mPointerView_auto");
                                            stringBuilder4.append(String.valueOf(this.touch_target_num));
                                            rawY += ((ViewPointerAuto) map3.get(stringBuilder4.toString())).getWidth() / 2;
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            int i = ((LayoutParams) map3.get(stringBuilder4.toString())).y;
                                            map = FloatingViewService.mPointerView_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mPointerView_auto");
                                            stringBuilder.append(String.valueOf(this.touch_target_num));
                                            i += ((ViewPointerAuto) map.get(stringBuilder.toString())).getWidth() / 2;
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            int i2 = ((LayoutParams) map.get(stringBuilder.toString())).x;
                                            Map map5 = FloatingViewService.mPointerView_auto;
                                            StringBuilder stringBuilder7 = new StringBuilder();
                                            stringBuilder7.append("mPointerView_auto");
                                            stringBuilder7.append(String.valueOf(this.touch_target_num));
                                            i2 += ((ViewPointerAuto) map5.get(stringBuilder7.toString())).getWidth() / 2;
                                            map5 = FloatingViewService.mParams_auto;
                                            stringBuilder7 = new StringBuilder();
                                            stringBuilder7.append("mParams_auto");
                                            stringBuilder7.append(this.touch_target_num);
                                            int i3 = ((LayoutParams) map5.get(stringBuilder7.toString())).y;
                                            Map map6 = FloatingViewService.mPointerView_auto;
                                            StringBuilder stringBuilder8 = new StringBuilder();
                                            stringBuilder8.append("mPointerView_auto");
                                            stringBuilder8.append(String.valueOf(this.touch_target_num));
                                            viewPointerAutoSwipe.assign(rawY, i, i2, i3 + (((ViewPointerAuto) map6.get(stringBuilder8.toString())).getWidth() / 2));
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mPointerView_auto_s");
                                            stringBuilder3.append(String.valueOf(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1)));
                                            ((ViewPointerAutoSwipe) map2.get(stringBuilder3.toString())).invalidate();
                                            windowManager = FloatingViewService.mWindowManager;
                                            map4 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto_s");
                                            stringBuilder2.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto_s");
                                            stringBuilder4.append(String.valueOf(Integer.valueOf(this.touch_target_num).intValue() - 1));
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            break;
                                        default:
                                            break;
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return false;
                            }
                        });
                        Map map9 = FloatingViewService.mPointerView_auto;
                        stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mPointerView_auto");
                        stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                        if (map9.get(stringBuilder4.toString()) != null) {
                            map9 = FloatingViewService.mPointerView_auto;
                            stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("mPointerView_auto");
                            stringBuilder4.append(String.valueOf(FloatingViewService.target_num));
                            if (!((ViewPointerAuto) map9.get(stringBuilder4.toString())).isShown()) {
                                WindowManager windowManager3 = FloatingViewService.mWindowManager;
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder12 = new StringBuilder();
                                stringBuilder12.append("mPointerView_auto");
                                stringBuilder12.append(String.valueOf(FloatingViewService.target_num));
                                View view4 = (View) map.get(stringBuilder12.toString());
                                map8 = FloatingViewService.mParams_auto;
                                stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("mParams_auto");
                                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                windowManager3.addView(view4, (ViewGroup.LayoutParams) map8.get(stringBuilder2.toString()));
                            }
                        }
                        edit.putInt("auto_target", FloatingViewService.target_num);
                        edit.apply();
                        Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
                        FloatingViewService.adding = true;
                    } else if (!FloatingViewService.purchased) {
                        Toast.makeText(FloatingViewService.this.getApplicationContext(), FloatingViewService.this.getResources().getText(R.string.purchase_yet), 0).show();
                    }
                }
            }
        });
        ((ImageView) mFloatingView.findViewById(R.id.add_btn)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    Editor edit = FloatingViewService.settings.edit();
                    FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                    stringBuilder.append(" | ");
                    stringBuilder.append(String.valueOf(FloatingViewService.purchase_num));
                    Log.d("target_num | purchase_num", stringBuilder.toString());
                    if (FloatingViewService.target_num < FloatingViewService.purchase_num) {
                        FloatingViewService.target_num++;
                        if (FloatingViewService.mPointerView_auto == null) {
                            FloatingViewService.mPointerView_auto = new HashMap();
                        }
                        Map map = FloatingViewService.px_auto;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("px_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.py_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("py_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), Float.valueOf(0.0f));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), new ViewPointerAuto(FloatingViewService.this.getApplicationContext()));
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder2.toString())).setClickable(true);
                        map = FloatingViewService.mPointerView_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map.get(stringBuilder2.toString())).setFocusable(true);
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        map.put(stringBuilder2.toString(), new LayoutParams(-2, -2, i2, 8, -3));
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder2.toString())).gravity = 51;
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder2.toString())).x = FloatingViewService.deviceHorizontalCenter - 50;
                        map = FloatingViewService.mParams_auto;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mParams_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        ((LayoutParams) map.get(stringBuilder2.toString())).y = FloatingViewService.deviceVerticalCenter - 50;
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("@drawable/target");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        String stringBuilder4 = stringBuilder3.toString();
                        Log.d("drawable uri : ", stringBuilder4);
                        final int identifier = FloatingViewService.this.getResources().getIdentifier(stringBuilder4, null, FloatingViewService.this.getPackageName());
                        Log.d("imageResource : ", String.valueOf(identifier));
                        Map map2 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map2.get(stringBuilder5.toString())).setBackgroundResource(identifier);
                        map2 = FloatingViewService.mPointerView_auto;
                        stringBuilder5 = new StringBuilder();
                        stringBuilder5.append("mPointerView_auto");
                        stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                        ((ViewPointerAuto) map2.get(stringBuilder5.toString())).setOnTouchListener(new OnTouchListener() {
                            private float initialPointX;
                            private float initialPointY;
                            private int initialX;
                            private int initialY;
                            private String touch_target_num;
                            private int vectorX;
                            private int vectorY;

                            public boolean onTouch(View view, MotionEvent motionEvent) {
                                try {
                                    Map map;
                                    StringBuilder stringBuilder;
                                    Map map2;
                                    StringBuilder stringBuilder2;
                                    StringBuilder stringBuilder3;
                                    Map map3;
                                    StringBuilder stringBuilder4;
                                    switch (motionEvent.getAction()) {
                                        case 0:
                                            String resourceEntryName = view.getResources().getResourceEntryName(identifier);
                                            if (resourceEntryName.length() > 7) {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 2, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            } else {
                                                this.touch_target_num = resourceEntryName.substring(resourceEntryName.length() - 1, resourceEntryName.length());
                                                Log.d("target name : ", resourceEntryName);
                                                Log.d("target sub name : ", this.touch_target_num);
                                            }
                                            Editor edit = FloatingViewService.settings.edit();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialX", ((LayoutParams) map.get(stringBuilder.toString())).x);
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            edit.putInt("initialY", ((LayoutParams) map.get(stringBuilder.toString())).y);
                                            edit.apply();
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialX = ((LayoutParams) map2.get(stringBuilder2.toString())).x;
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mParams_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            this.initialY = ((LayoutParams) map2.get(stringBuilder2.toString())).y;
                                            this.initialPointX = motionEvent.getRawX();
                                            this.initialPointY = motionEvent.getRawY();
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("px_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            String stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("py_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            stringBuilder5 = stringBuilder3.toString();
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            map2.put(stringBuilder5, Float.valueOf((float) ((LayoutParams) map3.get(stringBuilder4.toString())).y));
                                            break;
                                        case 1:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_up", stringBuilder2.toString());
                                            map2 = FloatingViewService.px_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("px_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            String stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).x));
                                            map2 = FloatingViewService.py_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("py_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder6 = stringBuilder2.toString();
                                            map = FloatingViewService.mParams_auto;
                                            stringBuilder = new StringBuilder();
                                            stringBuilder.append("mParams_auto");
                                            stringBuilder.append(this.touch_target_num);
                                            map2.put(stringBuilder6, Float.valueOf((float) ((LayoutParams) map.get(stringBuilder.toString())).y));
                                            int rawX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            int rawY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            if (Math.abs(rawX) < 5 && Math.abs(rawY) < 5 && !FloatingViewService.auto_click) {
                                                Intent intent = new Intent(FloatingViewService.this.getApplicationContext(), DelayActivity.class);
                                                intent.setFlags(268435456);
                                                Bundle bundle = new Bundle();
                                                bundle.putString("target_number", this.touch_target_num);
                                                intent.putExtras(bundle);
                                                FloatingViewService.this.startActivity(intent);
                                                break;
                                            }
                                        case 2:
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append(this.touch_target_num);
                                            stringBuilder2.append(" ");
                                            stringBuilder2.append(this.touch_target_num);
                                            Log.d("action_move", stringBuilder2.toString());
                                            this.vectorX = (int) (motionEvent.getRawX() - this.initialPointX);
                                            this.vectorY = (int) (motionEvent.getRawY() - this.initialPointY);
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).x = (int) (((float) this.initialX) + (((float) this.vectorX) * 1.0f));
                                            map2 = FloatingViewService.mParams_auto;
                                            stringBuilder3 = new StringBuilder();
                                            stringBuilder3.append("mParams_auto");
                                            stringBuilder3.append(this.touch_target_num);
                                            ((LayoutParams) map2.get(stringBuilder3.toString())).y = (int) (((float) this.initialY) + (((float) this.vectorY) * 1.0f));
                                            WindowManager windowManager = FloatingViewService.mWindowManager;
                                            Map map4 = FloatingViewService.mPointerView_auto;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto");
                                            stringBuilder2.append(this.touch_target_num);
                                            View view2 = (View) map4.get(stringBuilder2.toString());
                                            map3 = FloatingViewService.mParams_auto;
                                            stringBuilder4 = new StringBuilder();
                                            stringBuilder4.append("mParams_auto");
                                            stringBuilder4.append(this.touch_target_num);
                                            windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map3.get(stringBuilder4.toString()));
                                            break;
                                        default:
                                            break;
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return false;
                            }
                        });
                        Map map3 = FloatingViewService.mPointerView_auto;
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("mPointerView_auto");
                        stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                        if (map3.get(stringBuilder3.toString()) != null) {
                            map3 = FloatingViewService.mPointerView_auto;
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("mPointerView_auto");
                            stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                            if (!((ViewPointerAuto) map3.get(stringBuilder3.toString())).isShown()) {
                                WindowManager windowManager = FloatingViewService.mWindowManager;
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("mPointerView_auto");
                                stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                View view2 = (View) map.get(stringBuilder2.toString());
                                map2 = FloatingViewService.mParams_auto;
                                stringBuilder5 = new StringBuilder();
                                stringBuilder5.append("mParams_auto");
                                stringBuilder5.append(String.valueOf(FloatingViewService.target_num));
                                windowManager.addView(view2, (ViewGroup.LayoutParams) map2.get(stringBuilder5.toString()));
                            }
                        }
                        edit.putInt("auto_target", FloatingViewService.target_num);
                        edit.apply();
                        Log.d("add_btn target_num : ", String.valueOf(FloatingViewService.target_num));
                        FloatingViewService.adding = true;
                    } else if (!FloatingViewService.purchased) {
                        Toast.makeText(FloatingViewService.this.getApplicationContext(), FloatingViewService.this.getResources().getText(R.string.purchase_yet), 0).show();
                    }
                }
            }
        });
        ImageView imageView = (ImageView) mFloatingView.findViewById(R.id.remove_btn);
        imageView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    Editor edit = FloatingViewService.settings.edit();
                    int i = 0;
                    FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                    if (FloatingViewService.target_num > 0 && FloatingViewService.mPointerView_auto != null) {
                        int i2 = 0;
                        int i3 = i2;
                        while (i2 < FloatingViewService.swipe_target.size()) {
                            if (FloatingViewService.target_num == ((Integer) FloatingViewService.swipe_target.get(i2)).intValue()) {
                                Log.d("target_num == swipe_target.get : ", String.valueOf(FloatingViewService.target_num));
                                FloatingViewService.swipe_target.remove(i2);
                                FloatingViewService.swipe_target.remove(i2 - 1);
                                i3 = 1;
                            }
                            i2++;
                        }
                        Map map;
                        StringBuilder stringBuilder;
                        WindowManager windowManager;
                        Map map2;
                        StringBuilder stringBuilder2;
                        StringBuilder stringBuilder3;
                        if (i3 != 0) {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto_s");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num - 1));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_Before");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_Before");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num - 1));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_After");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_After");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num - 1));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_Before");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_After");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                        } else {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_Before");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointer_Auto_After");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.target_num));
                                    edit.putInt(stringBuilder3.toString(), 0);
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                        }
                    }
                    if (FloatingViewService.target_num == 0) {
                        while (i < FloatingViewService.swipe_target.size()) {
                            FloatingViewService.swipe_target.remove(i);
                            i++;
                        }
                        FloatingViewService.mPointerView_auto = null;
                        FloatingViewService.mPointerView_auto_swipe = null;
                    }
                }
            }
        });
        imageView.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View view) {
                int i;
                int i2;
                Editor edit = FloatingViewService.settings.edit();
                while (true) {
                    int i3 = 0;
                    i = 1;
                    if (FloatingViewService.target_num == 0 || FloatingViewService.mPointerView_auto == null) {
                    } else {
                        FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                        Log.d("remove_btn  target_num : ", String.valueOf(FloatingViewService.target_num));
                        i2 = 0;
                        while (i3 < FloatingViewService.swipe_target.size()) {
                            if (FloatingViewService.target_num == ((Integer) FloatingViewService.swipe_target.get(i3)).intValue()) {
                                Log.d("target_num == swipe_target.get : ", String.valueOf(FloatingViewService.target_num));
                                FloatingViewService.swipe_target.remove(i3);
                                FloatingViewService.swipe_target.remove(i3 - 1);
                                i2 = 1;
                            }
                            i3++;
                        }
                        Map map;
                        StringBuilder stringBuilder;
                        WindowManager windowManager;
                        Map map2;
                        StringBuilder stringBuilder2;
                        if (i2 != 0) {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto_s");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num - 1));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                        } else {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                            if (map.get(stringBuilder.toString()) != null) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                                if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                    windowManager = FloatingViewService.mWindowManager;
                                    map2 = FloatingViewService.mPointerView_auto;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                                    windowManager.removeView((View) map2.get(stringBuilder2.toString()));
                                    edit.putInt("auto_target", FloatingViewService.target_num - 1);
                                    edit.apply();
                                    FloatingViewService.target_num--;
                                    Log.d("target_num-- : ", String.valueOf(FloatingViewService.target_num));
                                }
                            }
                        }
                    }
                }
                for (i2 = 0; i2 < FloatingViewService.swipe_target.size(); i2++) {
                    FloatingViewService.swipe_target.remove(i2);
                }
                while (i < 48) {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("mPointer_Auto_Before");
                    stringBuilder3.append(String.valueOf(i));
                    edit.putInt(stringBuilder3.toString(), 0);
                    stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("mPointer_Auto_After");
                    stringBuilder3.append(String.valueOf(i));
                    edit.putInt(stringBuilder3.toString(), 0);
                    i++;
                }
                edit.putInt("auto_target", 0);
                edit.apply();
                FloatingViewService.target_num = 0;
                FloatingViewService.mPointerView_auto = null;
                FloatingViewService.mPointerView_auto_swipe = null;
                Toast.makeText(FloatingViewService.this.getApplicationContext(), "Initialized target", 0).show();
                return false;
            }
        });
        times = (int) settings.getFloat("click_times", 30.0f);
        imageView = (ImageView) mFloatingView.findViewById(R.id.play_btn);
        imageView.setBackgroundResource(R.drawable.autoclick_play);
        imageView.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (FloatingViewService.auto_click) {
                    Log.d("auto_click", "false");
                    FloatingViewService.auto_click = false;
                    imageView.setBackgroundResource(R.drawable.autoclick_play);
                } else {
                    Log.d("auto_click", "true");
                    FloatingViewService.target_num = FloatingViewService.settings.getInt("auto_target", 0);
                    if (AutoClicker.instance != null) {
                        Log.d("AutoClicker.instance", "not null");
                        if (FloatingViewService.target_num == 0) {
                            FloatingViewService.auto_click = false;
                            return false;
                        }
                        FloatingViewService.auto_click = true;
                        imageView.setBackgroundResource(0);
                        imageView.setBackgroundResource(R.drawable.pause);
                        FloatingViewService.expandedView.setBackgroundColor(ContextCompat.getColor(FloatingViewService.this.getApplicationContext(), R.color.defaultcolor2));
                        FloatingViewService.mTracker.setScreenName("FloatingViewService - AUTO_CLICK");
                        FloatingViewService.mTracker.send(new ScreenViewBuilder().build());
                        final int[] iArr = new int[FloatingViewService.target_num];
                        final int[] iArr2 = new int[FloatingViewService.target_num];
                        Map map = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(String.valueOf(FloatingViewService.target_num));
                        int width = ((ViewPointerAuto) map.get(stringBuilder.toString())).getWidth() / 2;
                        Map map2 = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto");
                        stringBuilder2.append(String.valueOf(FloatingViewService.target_num));
                        int height = ((ViewPointerAuto) map2.get(stringBuilder2.toString())).getHeight();
                        final int i = 1000 / AutoClickSpeed.clickpersecond;
                        for (int i2 = 1; i2 <= FloatingViewService.target_num; i2++) {
                            Map map3;
                            StringBuilder stringBuilder3;
                            Map map4;
                            StringBuilder stringBuilder4;
                            int i3;
                            Map map5 = FloatingViewService.mPointerView_auto;
                            StringBuilder stringBuilder5 = new StringBuilder();
                            stringBuilder5.append("mPointerView_auto");
                            stringBuilder5.append(String.valueOf(i2));
                            if (((ViewPointerAuto) map5.get(stringBuilder5.toString())).isShown()) {
                                map5 = FloatingViewService.mParams_auto;
                                stringBuilder5 = new StringBuilder();
                                stringBuilder5.append("mParams_auto");
                                stringBuilder5.append(String.valueOf(i2));
                                LayoutParams layoutParams = (LayoutParams) map5.get(stringBuilder5.toString());
                                layoutParams.flags |= 16;
                                WindowManager windowManager = FloatingViewService.mWindowManager;
                                map3 = FloatingViewService.mPointerView_auto;
                                stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("mPointerView_auto");
                                stringBuilder3.append(String.valueOf(i2));
                                View view2 = (View) map3.get(stringBuilder3.toString());
                                map4 = FloatingViewService.mParams_auto;
                                stringBuilder4 = new StringBuilder();
                                stringBuilder4.append("mParams_auto");
                                stringBuilder4.append(String.valueOf(i2));
                                windowManager.updateViewLayout(view2, (ViewGroup.LayoutParams) map4.get(stringBuilder4.toString()));
                            }
                            for (i3 = 0; i3 < FloatingViewService.swipe_target.size(); i3++) {
                                Log.d("swipe target num : ", String.valueOf(FloatingViewService.swipe_target.get(i3)));
                                if (i2 == ((Integer) FloatingViewService.swipe_target.get(i3)).intValue()) {
                                    Log.d("swipe target num matched : ", String.valueOf(FloatingViewService.swipe_target.get(i3)));
                                    map3 = FloatingViewService.mPointerView_auto_swipe;
                                    stringBuilder3 = new StringBuilder();
                                    stringBuilder3.append("mPointerView_auto_s");
                                    stringBuilder3.append(String.valueOf(FloatingViewService.swipe_target.get(i3)));
                                    if (map3.get(stringBuilder3.toString()) != null) {
                                        map3 = FloatingViewService.mPointerView_auto_swipe;
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append("mPointerView_auto_s");
                                        stringBuilder3.append(String.valueOf(FloatingViewService.swipe_target.get(i3)));
                                        ((ViewPointerAutoSwipe) map3.get(stringBuilder3.toString())).setPaint_Play();
                                        map3 = FloatingViewService.mPointerView_auto_swipe;
                                        stringBuilder3 = new StringBuilder();
                                        stringBuilder3.append("mPointerView_auto_s");
                                        stringBuilder3.append(String.valueOf(FloatingViewService.swipe_target.get(i3)));
                                        ((ViewPointerAutoSwipe) map3.get(stringBuilder3.toString())).invalidate();
                                        WindowManager windowManager2 = FloatingViewService.mWindowManager;
                                        map4 = FloatingViewService.mPointerView_auto_swipe;
                                        stringBuilder4 = new StringBuilder();
                                        stringBuilder4.append("mPointerView_auto_s");
                                        stringBuilder4.append(FloatingViewService.swipe_target.get(i3));
                                        View view3 = (View) map4.get(stringBuilder4.toString());
                                        Map map6 = FloatingViewService.mParams_auto;
                                        StringBuilder stringBuilder6 = new StringBuilder();
                                        stringBuilder6.append("mParams_auto_s");
                                        stringBuilder6.append(FloatingViewService.swipe_target.get(i3));
                                        windowManager2.updateViewLayout(view3, (ViewGroup.LayoutParams) map6.get(stringBuilder6.toString()));
                                    }
                                }
                            }
                            i3 = i2 - 1;
                            map3 = FloatingViewService.mParams_auto;
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("mParams_auto");
                            stringBuilder3.append(String.valueOf(i2));
                            iArr[i3] = ((LayoutParams) map3.get(stringBuilder3.toString())).x + width;
                            map3 = FloatingViewService.mParams_auto;
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("mParams_auto");
                            stringBuilder3.append(String.valueOf(i2));
                            iArr2[i3] = ((LayoutParams) map3.get(stringBuilder3.toString())).y + height;
                        }
                        final Display defaultDisplay = ((WindowManager) FloatingViewService.this.getSystemService("window")).getDefaultDisplay();
                        AutoClickSpeed.test_flag = true;
                        AutoClickSpeed.start_time = (double) System.currentTimeMillis();
                        Handler handler = new Handler();
                        final Handler handler2 = handler;
                        handler.post(new Runnable() {
                            public void run() {
                                /*
                                r9 = this;
                                r0 = r3;
                                r0 = r0.getRotation();
                                r1 = 0;
                                r2 = 1;
                                switch(r0) {
                                    case 0: goto L_0x0147;
                                    case 1: goto L_0x00aa;
                                    case 2: goto L_0x01d9;
                                    case 3: goto L_0x000d;
                                    default: goto L_0x000b;
                                };
                            L_0x000b:
                                goto L_0x01d9;
                            L_0x000d:
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_num;
                                if (r0 > r3) goto L_0x00a6;
                            L_0x0013:
                                r0 = r1;
                                r3 = r0;
                            L_0x0015:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r4 = r4.size();
                                if (r0 >= r4) goto L_0x0031;
                            L_0x001d:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r5 = r5.get(r0);
                                r5 = (java.lang.Integer) r5;
                                r5 = r5.intValue();
                                if (r4 != r5) goto L_0x002e;
                            L_0x002d:
                                r3 = r2;
                            L_0x002e:
                                r0 = r0 + 1;
                                goto L_0x0015;
                            L_0x0031:
                                if (r3 == 0) goto L_0x008c;
                            L_0x0033:
                                r0 = "ROTATION_270";
                                r3 = "ROTATION_270";
                                android.util.Log.d(r0, r3);
                                r0 = "target_rotation-1";
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = "target_x.length";
                                r3 = r4;
                                r3 = r3.length;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = r4;
                                r0 = r0.length;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r0 = r0 - r3;
                                if (r0 <= r2) goto L_0x01d9;
                            L_0x005b:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r5 = r4;
                                r6 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5[r6];
                                r6 = r5;
                                r7 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r6 = r6[r7];
                                r0.swipe(r3, r4, r5, r6);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r3 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.swipe_duration_time;	 Catch:{ InterruptedException -> 0x01d9 }
                                r3 = (long) r3;	 Catch:{ InterruptedException -> 0x01d9 }
                                java.lang.Thread.sleep(r3);	 Catch:{ InterruptedException -> 0x01d9 }
                                goto L_0x01d9;
                            L_0x008c:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r0.click(r3, r4);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                goto L_0x01d9;
                            L_0x00a6:
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r2;
                                goto L_0x01d9;
                            L_0x00aa:
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_num;
                                if (r0 > r3) goto L_0x0143;
                            L_0x00b0:
                                r0 = r1;
                                r3 = r0;
                            L_0x00b2:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r4 = r4.size();
                                if (r0 >= r4) goto L_0x00ce;
                            L_0x00ba:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r5 = r5.get(r0);
                                r5 = (java.lang.Integer) r5;
                                r5 = r5.intValue();
                                if (r4 != r5) goto L_0x00cb;
                            L_0x00ca:
                                r3 = r2;
                            L_0x00cb:
                                r0 = r0 + 1;
                                goto L_0x00b2;
                            L_0x00ce:
                                if (r3 == 0) goto L_0x0129;
                            L_0x00d0:
                                r0 = "ROTATION_90";
                                r3 = "ROTATION_90";
                                android.util.Log.d(r0, r3);
                                r0 = "target_rotation-1";
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = "target_x.length";
                                r3 = r4;
                                r3 = r3.length;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = r4;
                                r0 = r0.length;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r0 = r0 - r3;
                                if (r0 <= r2) goto L_0x01d9;
                            L_0x00f8:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r5 = r4;
                                r6 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5[r6];
                                r6 = r5;
                                r7 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r6 = r6[r7];
                                r0.swipe(r3, r4, r5, r6);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r3 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.swipe_duration_time;	 Catch:{ InterruptedException -> 0x01d9 }
                                r3 = (long) r3;	 Catch:{ InterruptedException -> 0x01d9 }
                                java.lang.Thread.sleep(r3);	 Catch:{ InterruptedException -> 0x01d9 }
                                goto L_0x01d9;
                            L_0x0129:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r0.click(r3, r4);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                goto L_0x01d9;
                            L_0x0143:
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r2;
                                goto L_0x01d9;
                            L_0x0147:
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_num;
                                if (r0 > r3) goto L_0x01d7;
                            L_0x014d:
                                r0 = r1;
                                r3 = r0;
                            L_0x014f:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r4 = r4.size();
                                if (r0 >= r4) goto L_0x016b;
                            L_0x0157:
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.swipe_target;
                                r5 = r5.get(r0);
                                r5 = (java.lang.Integer) r5;
                                r5 = r5.intValue();
                                if (r4 != r5) goto L_0x0168;
                            L_0x0167:
                                r3 = r2;
                            L_0x0168:
                                r0 = r0 + 1;
                                goto L_0x014f;
                            L_0x016b:
                                if (r3 == 0) goto L_0x01be;
                            L_0x016d:
                                r0 = "target_rotation-1";
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = "target_x.length";
                                r3 = r4;
                                r3 = r3.length;
                                r3 = java.lang.String.valueOf(r3);
                                android.util.Log.d(r0, r3);
                                r0 = r4;
                                r0 = r0.length;
                                r3 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r3 = r3 - r2;
                                r0 = r0 - r3;
                                if (r0 <= r2) goto L_0x01d9;
                            L_0x018e:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r5 = r4;
                                r6 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5[r6];
                                r6 = r5;
                                r7 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r6 = r6[r7];
                                r0.swipe(r3, r4, r5, r6);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                r3 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.swipe_duration_time;	 Catch:{ InterruptedException -> 0x01d9 }
                                r3 = (long) r3;	 Catch:{ InterruptedException -> 0x01d9 }
                                java.lang.Thread.sleep(r3);	 Catch:{ InterruptedException -> 0x01d9 }
                                goto L_0x01d9;
                            L_0x01be:
                                r0 = com.autoclicker.autoswiper.service.AutoClicker.instance;
                                r3 = r4;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r4 = r4 - r2;
                                r3 = r3[r4];
                                r4 = r5;
                                r5 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r5 = r5 - r2;
                                r4 = r4[r5];
                                r0.click(r3, r4);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.target_rotation;
                                r0 = r0 + r2;
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r0;
                                goto L_0x01d9;
                            L_0x01d7:
                                com.autoclicker.autoswiper.FloatingViewService.target_rotation = r2;
                            L_0x01d9:
                                r0 = com.autoclicker.autoswiper.FloatingViewService.auto_click;
                                r3 = 2130968628; // 0x7f040034 float:1.7545915E38 double:1.0528383915E-314;
                                r4 = 2131099731; // 0x7f060053 float:1.7811823E38 double:1.052903165E-314;
                                if (r0 == 0) goto L_0x0251;
                            L_0x01e3:
                                r5 = java.lang.System.currentTimeMillis();
                                r5 = (double) r5;
                                r7 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.start_time;
                                r5 = r5 - r7;
                                com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.interval = r5;
                                r0 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.test_flag;
                                if (r0 == 0) goto L_0x0205;
                            L_0x01f1:
                                r5 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.duration_time;
                                r7 = 0;
                                r0 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1));
                                if (r0 >= 0) goto L_0x0205;
                            L_0x01f9:
                                r0 = r6;
                                r1 = r7;
                                r1 = r1 / 2;
                                r1 = (long) r1;
                                r0.postDelayed(r9, r1);
                                goto L_0x02b8;
                            L_0x0205:
                                r0 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.test_flag;
                                if (r0 == 0) goto L_0x021d;
                            L_0x0209:
                                r5 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.interval;
                                r7 = com.autoclicker.autoswiper.servicecontrol.AutoClickSpeed.duration_time;
                                r0 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1));
                                if (r0 >= 0) goto L_0x021d;
                            L_0x0211:
                                r0 = r6;
                                r1 = r7;
                                r1 = r1 / 2;
                                r1 = (long) r1;
                                r0.postDelayed(r9, r1);
                                goto L_0x02b8;
                            L_0x021d:
                                com.autoclicker.autoswiper.FloatingViewService.auto_click = r1;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r0 = r0;
                                r0.setBackgroundResource(r4);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.settings;
                                r2 = "auto_target";
                                r0 = r0.getInt(r2, r1);
                                com.autoclicker.autoswiper.FloatingViewService.target_num = r0;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.expandedView;
                                r1 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r1 = com.autoclicker.autoswiper.FloatingViewService.this;
                                r1 = r1.getApplicationContext();
                                r1 = android.support.v4.content.ContextCompat.getColor(r1, r3);
                                r0.setBackgroundColor(r1);
                                r0 = new android.os.Handler;
                                r0.<init>();
                                r1 = new com.autoclicker.autoswiper.FloatingViewService$6$1$1;
                                r1.<init>();
                                r2 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
                                r0.postDelayed(r1, r2);
                                goto L_0x02b8;
                            L_0x0251:
                                r0 = "auto click";
                                r5 = "end";
                                android.util.Log.d(r0, r5);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r0 = r0;
                                r0.setBackgroundResource(r4);
                                r0 = com.autoclicker.autoswiper.FloatingViewService.settings;
                                r4 = "auto_target";
                                r0 = r0.getInt(r4, r1);
                                com.autoclicker.autoswiper.FloatingViewService.target_num = r0;
                                r0 = com.autoclicker.autoswiper.FloatingViewService.expandedView;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r4 = com.autoclicker.autoswiper.FloatingViewService.this;
                                r4 = r4.getApplicationContext();
                                r3 = android.support.v4.content.ContextCompat.getColor(r4, r3);
                                r0.setBackgroundColor(r3);
                                r0 = new com.autoclicker.autoswiper.FloatingViewService$6$1$2;
                                r0.<init>();
                                r3 = r6;
                                r4 = 0;
                                r3.postDelayed(r0, r4);
                                r0 = new java.util.Random;
                                r0.<init>();
                                r3 = 6;
                                r0 = r0.nextInt(r3);
                                r0 = r0 + r2;
                                if (r0 != r2) goto L_0x02b8;
                            L_0x0293:
                                r0 = com.autoclicker.autoswiper.FloatingViewService.settings;
                                r2 = "rate";
                                r0 = r0.getBoolean(r2, r1);
                                if (r0 != 0) goto L_0x02b8;
                            L_0x029d:
                                r0 = new android.content.Intent;
                                r1 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r1 = com.autoclicker.autoswiper.FloatingViewService.this;
                                r1 = r1.getApplicationContext();
                                r2 = com.autoclicker.autoswiper.servicecontrol.RateActivity.class;
                                r0.<init>(r1, r2);
                                r1 = 268435456; // 0x10000000 float:2.5243549E-29 double:1.32624737E-315;
                                r0.setFlags(r1);
                                r9 = com.autoclicker.autoswiper.FloatingViewService.AnonymousClass6.this;
                                r9 = com.autoclicker.autoswiper.FloatingViewService.this;
                                r9.startActivity(r0);
                            L_0x02b8:
                                return;
                                */
                                throw new UnsupportedOperationException("Method not decompiled: com.autoclicker.autoswiper.FloatingViewService$6$AnonymousClass1.run():void");
                            }
                        });
                    } else {
                        Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
                        intent.addFlags(268435456);
                        FloatingViewService.this.startActivity(intent);
                    }
                }
                return false;
            }
        });
        ((ImageView) mFloatingView.findViewById(R.id.btnCapture)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    Intent intent = new Intent(FloatingViewService.this.getApplicationContext(), AllSettings.class);
                    intent.setFlags(268435456);
                    FloatingViewService.this.startActivity(intent);
                }
            }
        });
        ((ImageView) mFloatingView.findViewById(R.id.close_button)).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    FloatingViewService.collapsedView.setVisibility(0);
                    FloatingViewService.expandedView.setVisibility(8);
                    if (FloatingViewService.mPointerView_auto == null) {
                        FloatingViewService.mPointerView_auto = new HashMap();
                    }
                    for (int i = 1; i <= FloatingViewService.mPointerView_auto.size(); i++) {
                        Map map = FloatingViewService.mPointerView_auto;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto");
                        stringBuilder.append(String.valueOf(i));
                        if (map.get(stringBuilder.toString()) != null) {
                            map = FloatingViewService.mPointerView_auto;
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("mPointerView_auto");
                            stringBuilder.append(String.valueOf(i));
                            if (((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                map = FloatingViewService.mPointerView_auto;
                                stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(i));
                                ((ViewPointerAuto) map.get(stringBuilder.toString())).setVisibility(8);
                                for (int i2 = 0; i2 < FloatingViewService.swipe_target.size(); i2++) {
                                    StringBuilder stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append(String.valueOf(i));
                                    stringBuilder2.append(" | ");
                                    stringBuilder2.append(String.valueOf(FloatingViewService.swipe_target.get(i2)));
                                    Log.d("i | swipe_target num", stringBuilder2.toString());
                                    if (i == ((Integer) FloatingViewService.swipe_target.get(i2)).intValue()) {
                                        Map map2 = FloatingViewService.mPointerView_auto_swipe;
                                        stringBuilder2 = new StringBuilder();
                                        stringBuilder2.append("mPointerView_auto_s");
                                        stringBuilder2.append(String.valueOf(i));
                                        if (map2.get(stringBuilder2.toString()) != null) {
                                            map2 = FloatingViewService.mPointerView_auto_swipe;
                                            stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("mPointerView_auto_s");
                                            stringBuilder2.append(String.valueOf(i));
                                            if (((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).isShown()) {
                                                map2 = FloatingViewService.mPointerView_auto_swipe;
                                                stringBuilder2 = new StringBuilder();
                                                stringBuilder2.append("mPointerView_auto_s");
                                                stringBuilder2.append(String.valueOf(i));
                                                ((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).setVisibility(8);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        share = (ImageView) mFloatingView.findViewById(R.id.share_button);
        share.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!FloatingViewService.auto_click) {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", "Auto Clicker - Auto Swiper");
                    String string = FloatingViewService.this.getResources().getString(R.string.recommend_app);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string);
                    stringBuilder.append("https://play.google.com/store/apps/details?id=com.autoclicker.autoswiper \n\n");
                    intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                    FloatingViewService.this.startActivity(Intent.createChooser(intent, "Share via"));
                }
            }
        });
        mFloatingView.findViewById(R.id.root_container).setOnTouchListener(new OnTouchListener() {
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case 0:
                        this.initialX = FloatingViewService.params.x;
                        this.initialY = FloatingViewService.params.y;
                        this.initialTouchX = motionEvent.getRawX();
                        this.initialTouchY = motionEvent.getRawY();
                        return true;
                    case 1:
                        int rawX = (int) (motionEvent.getRawX() - this.initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - this.initialTouchY);
                        if (Math.abs(rawX) < 3 && Math.abs(rawY) < 3 && FloatingViewService.isViewCollapsed()) {
                            FloatingViewService.collapsedView.setVisibility(8);
                            FloatingViewService.expandedView.setVisibility(0);
                            for (rawY = 1; rawY <= FloatingViewService.mPointerView_auto.size(); rawY++) {
                                Map map = FloatingViewService.mPointerView_auto;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("mPointerView_auto");
                                stringBuilder.append(String.valueOf(rawY));
                                if (map.get(stringBuilder.toString()) != null) {
                                    map = FloatingViewService.mPointerView_auto;
                                    stringBuilder = new StringBuilder();
                                    stringBuilder.append("mPointerView_auto");
                                    stringBuilder.append(String.valueOf(rawY));
                                    if (!((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                                        map = FloatingViewService.mPointerView_auto;
                                        stringBuilder = new StringBuilder();
                                        stringBuilder.append("mPointerView_auto");
                                        stringBuilder.append(String.valueOf(rawY));
                                        ((ViewPointerAuto) map.get(stringBuilder.toString())).setVisibility(0);
                                        for (rawX = 0; rawX < FloatingViewService.swipe_target.size(); rawX++) {
                                            if (rawY == ((Integer) FloatingViewService.swipe_target.get(rawX)).intValue()) {
                                                Map map2 = FloatingViewService.mPointerView_auto_swipe;
                                                StringBuilder stringBuilder2 = new StringBuilder();
                                                stringBuilder2.append("mPointerView_auto_s");
                                                stringBuilder2.append(String.valueOf(rawY));
                                                if (map2.get(stringBuilder2.toString()) != null) {
                                                    map2 = FloatingViewService.mPointerView_auto_swipe;
                                                    stringBuilder2 = new StringBuilder();
                                                    stringBuilder2.append("mPointerView_auto_s");
                                                    stringBuilder2.append(String.valueOf(rawY));
                                                    if (!((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).isShown()) {
                                                        map2 = FloatingViewService.mPointerView_auto_swipe;
                                                        stringBuilder2 = new StringBuilder();
                                                        stringBuilder2.append("mPointerView_auto_s");
                                                        stringBuilder2.append(String.valueOf(rawY));
                                                        ((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).setVisibility(0);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        return true;
                    case 2:
                        FloatingViewService.params.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                        FloatingViewService.params.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));
                        FloatingViewService.mWindowManager.updateViewLayout(FloatingViewService.mFloatingView, FloatingViewService.params);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    public static void expandView() {
        collapsedView.setVisibility(8);
        expandedView.setVisibility(0);
        for (int i = 1; i <= mPointerView_auto.size(); i++) {
            Map map = mPointerView_auto;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("mPointerView_auto");
            stringBuilder.append(String.valueOf(i));
            if (map.get(stringBuilder.toString()) != null) {
                map = mPointerView_auto;
                stringBuilder = new StringBuilder();
                stringBuilder.append("mPointerView_auto");
                stringBuilder.append(String.valueOf(i));
                if (!((ViewPointerAuto) map.get(stringBuilder.toString())).isShown()) {
                    map = mPointerView_auto;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointerView_auto");
                    stringBuilder.append(String.valueOf(i));
                    ((ViewPointerAuto) map.get(stringBuilder.toString())).setVisibility(0);
                    for (int i2 = 0; i2 < swipe_target.size(); i2++) {
                        if (i == ((Integer) swipe_target.get(i2)).intValue()) {
                            Map map2 = mPointerView_auto_swipe;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("mPointerView_auto_s");
                            stringBuilder2.append(String.valueOf(i));
                            if (map2.get(stringBuilder2.toString()) != null) {
                                map2 = mPointerView_auto_swipe;
                                stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("mPointerView_auto_s");
                                stringBuilder2.append(String.valueOf(i));
                                if (!((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).isShown()) {
                                    map2 = mPointerView_auto_swipe;
                                    stringBuilder2 = new StringBuilder();
                                    stringBuilder2.append("mPointerView_auto_s");
                                    stringBuilder2.append(String.valueOf(i));
                                    ((ViewPointerAutoSwipe) map2.get(stringBuilder2.toString())).setVisibility(0);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void displayMetrics2() throws RemoteException {
        Display defaultDisplay = mWindowManager.getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        deviceWidth = displayMetrics.widthPixels;
        deviceHeight = displayMetrics.heightPixels;
        deviceHorizontalCenter = (deviceWidth - mFloatingView.getWidth()) >> 1;
        deviceVerticalCenter = (deviceHeight - mFloatingView.getHeight()) >> 1;
        Log.d("deviceHorizontalCenter : ", String.valueOf(deviceHorizontalCenter));
        Log.d("deviceVerticalCenter : ", String.valueOf(deviceVerticalCenter));
    }

    public static boolean isViewCollapsed() {
        return mFloatingView == null || mFloatingView.findViewById(R.id.collapse_view).getVisibility() == 0;
    }

    public void remove_flag_not_touchable() {
        for (int i = 1; i <= target_num; i++) {
            Map map;
            StringBuilder stringBuilder;
            Map map2;
            StringBuilder stringBuilder2;
            Map map3 = mPointerView_auto;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("mPointerView_auto");
            stringBuilder3.append(String.valueOf(i));
            if (((ViewPointerAuto) map3.get(stringBuilder3.toString())).isShown()) {
                map3 = mParams_auto;
                stringBuilder3 = new StringBuilder();
                stringBuilder3.append("mParams_auto");
                stringBuilder3.append(String.valueOf(i));
                LayoutParams layoutParams = (LayoutParams) map3.get(stringBuilder3.toString());
                layoutParams.flags &= -17;
                WindowManager windowManager = mWindowManager;
                map = mPointerView_auto;
                stringBuilder = new StringBuilder();
                stringBuilder.append("mPointerView_auto");
                stringBuilder.append(String.valueOf(i));
                View view = (View) map.get(stringBuilder.toString());
                map2 = mParams_auto;
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("mParams_auto");
                stringBuilder2.append(String.valueOf(i));
                windowManager.updateViewLayout(view, (ViewGroup.LayoutParams) map2.get(stringBuilder2.toString()));
            }
            for (int i2 = 0; i2 < swipe_target.size(); i2++) {
                Log.d("swipe target num : ", String.valueOf(swipe_target.get(i2)));
                if (i == ((Integer) swipe_target.get(i2)).intValue()) {
                    Log.d("swipe target num matched", String.valueOf(swipe_target.get(i2)));
                    map = mPointerView_auto_swipe;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("mPointerView_auto_s");
                    stringBuilder.append(String.valueOf(swipe_target.get(i2)));
                    if (map.get(stringBuilder.toString()) != null) {
                        map = mPointerView_auto_swipe;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto_s");
                        stringBuilder.append(String.valueOf(swipe_target.get(i2)));
                        ((ViewPointerAutoSwipe) map.get(stringBuilder.toString())).setPaint_Not_Play();
                        map = mPointerView_auto_swipe;
                        stringBuilder = new StringBuilder();
                        stringBuilder.append("mPointerView_auto_s");
                        stringBuilder.append(String.valueOf(swipe_target.get(i2)));
                        ((ViewPointerAutoSwipe) map.get(stringBuilder.toString())).invalidate();
                        WindowManager windowManager2 = mWindowManager;
                        map2 = mPointerView_auto_swipe;
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append("mPointerView_auto_s");
                        stringBuilder2.append(swipe_target.get(i2));
                        View view2 = (View) map2.get(stringBuilder2.toString());
                        Map map4 = mParams_auto;
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("mParams_auto_s");
                        stringBuilder4.append(swipe_target.get(i2));
                        windowManager2.updateViewLayout(view2, (ViewGroup.LayoutParams) map4.get(stringBuilder4.toString()));
                    }
                }
            }
        }
    }

    private boolean isNetworkConnected() {
        return ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }

    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
        if (mFloatingView != null) {
            mWindowManager.removeView(mFloatingView);
        }
    }
}
