package com.autoclicker.autoswiper.billing;

public interface BillingProvider {
    BillingManager getBillingManager();

    boolean isGoldMonthlySubscribed();

    boolean isGoldYearlySubscribed();

    boolean isPremiumPurchased();

    boolean isTankFull();
}
