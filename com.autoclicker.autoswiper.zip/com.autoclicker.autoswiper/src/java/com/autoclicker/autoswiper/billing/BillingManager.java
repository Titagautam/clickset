package com.autoclicker.autoswiper.billing;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.Purchase.PurchasesResult;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsParams.Builder;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.autoclicker.autoswiper.FloatingViewService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BillingManager implements PurchasesUpdatedListener {
    private static final String BASE_64_ENCODED_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnuYyUQGwZj1UwXdaJNjrpG9eq+MHJxj4qqh/NmF0ozGjWWYtfHnAQa4XyT5ULl5H32u0W2FWDnAaGaOvBrE+mlYwiK4NIhTpl/VWHs4UXGU/Rdh9VG/IsAzrrEL6Os5G1TS3OHyvAQdNeoT3WYiq+lCAXEeqVk/eq27hL9V/LXGct4wpRiKCVHlcBzRsb1reZcAsj9BEQ9rzKwYdUvOzkxuhg4xVPjNh0SkmEHnrF5Y1guSFQ9SP6R6aRgOuZVywiQABnUklv3JR6I7942Jd55XmhM555PTdpNQEoMhixUAyxrmO9krkv6AAZmabh3Yr1p8w0CB+n7PlNN//Wy6VwwIDAQAB";
    public static final int BILLING_MANAGER_NOT_INITIALIZED = -1;
    private static final String TAG = "BillingManager";
    private final Activity mActivity;
    private BillingClient mBillingClient;
    private int mBillingClientResponseCode = -1;
    private final BillingUpdatesListener mBillingUpdatesListener;
    private boolean mIsServiceConnected;
    private final List<Purchase> mPurchases = new ArrayList();
    private Set<String> mTokensToBeConsumed;

    public interface BillingUpdatesListener {
        void onBillingClientSetupFinished();

        void onConsumeFinished(String str, int i);

        void onPurchasesUpdated(List<Purchase> list);
    }

    public interface ServiceConnectedListener {
        void onServiceConnected(int i);
    }

    public BillingManager(Activity activity, BillingUpdatesListener billingUpdatesListener) {
        Log.d("BillingManager", "Creating Billing client.");
        this.mActivity = activity;
        this.mBillingUpdatesListener = billingUpdatesListener;
        this.mBillingClient = BillingClient.newBuilder(this.mActivity).setListener(this).build();
        Log.d("BillingManager", "Starting setup.");
        startServiceConnection(new Runnable() {
            public void run() {
                BillingManager.this.mBillingUpdatesListener.onBillingClientSetupFinished();
                Log.d("BillingManager", "Setup successful. Querying inventory.");
                BillingManager.this.queryPurchases();
            }
        });
    }

    public void onPurchasesUpdated(int i, List<Purchase> list) {
        if (i == 0) {
            for (Purchase handlePurchase : list) {
                handlePurchase(handlePurchase);
            }
            this.mBillingUpdatesListener.onPurchasesUpdated(this.mPurchases);
        } else if (i == 1) {
            Log.i("BillingManager", "onPurchasesUpdated() - user cancelled the purchase flow - skipping");
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("onPurchasesUpdated() got unknown resultCode: ");
            stringBuilder.append(i);
            Log.w("BillingManager", stringBuilder.toString());
        }
    }

    public void initiatePurchaseFlow(String str, String str2) {
        initiatePurchaseFlow(str, null, str2);
    }

    public void initiatePurchaseFlow(final String str, final ArrayList<String> arrayList, final String str2) {
        executeServiceRequest(new Runnable() {
            public void run() {
                String str = "BillingManager";
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Launching in-app purchase flow. Replace old SKU? ");
                stringBuilder.append(arrayList != null);
                Log.d(str, stringBuilder.toString());
                BillingManager.this.mBillingClient.launchBillingFlow(BillingManager.this.mActivity, BillingFlowParams.newBuilder().setSku(str).setType(str2).setOldSkus(arrayList).build());
            }
        });
    }

    public Context getContext() {
        return this.mActivity;
    }

    public void destroy() {
        Log.d("BillingManager", "Destroying the manager.");
        if (this.mBillingClient != null && this.mBillingClient.isReady()) {
            this.mBillingClient.endConnection();
            this.mBillingClient = null;
        }
    }

    public void querySkuDetailsAsync(final String str, final List<String> list, final SkuDetailsResponseListener skuDetailsResponseListener) {
        executeServiceRequest(new Runnable() {
            public void run() {
                Builder newBuilder = SkuDetailsParams.newBuilder();
                newBuilder.setSkusList(list).setType(str);
                BillingManager.this.mBillingClient.querySkuDetailsAsync(newBuilder.build(), new SkuDetailsResponseListener() {
                    public void onSkuDetailsResponse(int i, List<SkuDetails> list) {
                        skuDetailsResponseListener.onSkuDetailsResponse(i, list);
                    }
                });
            }
        });
    }

    public void consumeAsync(final String str) {
        if (this.mTokensToBeConsumed == null) {
            this.mTokensToBeConsumed = new HashSet();
        } else if (this.mTokensToBeConsumed.contains(str)) {
            Log.i("BillingManager", "Token was already scheduled to be consumed - skipping...");
            return;
        }
        this.mTokensToBeConsumed.add(str);
        final AnonymousClass4 anonymousClass4 = new ConsumeResponseListener() {
            public void onConsumeResponse(int i, String str) {
                BillingManager.this.mBillingUpdatesListener.onConsumeFinished(str, i);
            }
        };
        executeServiceRequest(new Runnable() {
            public void run() {
                BillingManager.this.mBillingClient.consumeAsync(str, anonymousClass4);
            }
        });
    }

    public int getBillingClientResponseCode() {
        return this.mBillingClientResponseCode;
    }

    private void handlePurchase(Purchase purchase) {
        this.mPurchases.add(purchase);
    }

    private void onQueryPurchasesFinished(PurchasesResult purchasesResult) {
        if (this.mBillingClient == null || purchasesResult.getResponseCode() != 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Billing client was null or result code (");
            stringBuilder.append(purchasesResult.getResponseCode());
            stringBuilder.append(") was bad - quitting");
            Log.w("BillingManager", stringBuilder.toString());
            return;
        }
        Log.d("BillingManager", "Query inventory was successful.");
        this.mPurchases.clear();
        onPurchasesUpdated(0, purchasesResult.getPurchasesList());
    }

    public boolean areSubscriptionsSupported() {
        int isFeatureSupported = this.mBillingClient.isFeatureSupported("subscriptions");
        if (isFeatureSupported != 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("areSubscriptionsSupported() got an error response: ");
            stringBuilder.append(isFeatureSupported);
            Log.w("BillingManager", stringBuilder.toString());
        }
        return isFeatureSupported == 0;
    }

    public void queryPurchases() {
        executeServiceRequest(new Runnable() {
            public void run() {
                long currentTimeMillis = System.currentTimeMillis();
                if (BillingManager.this.mBillingClient != null) {
                    PurchasesResult queryPurchases = BillingManager.this.mBillingClient.queryPurchases("inapp");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Querying purchases elapsed time: ");
                    stringBuilder.append(System.currentTimeMillis() - currentTimeMillis);
                    stringBuilder.append("ms");
                    Log.i("BillingManager", stringBuilder.toString());
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("getPurchasesList size : ");
                    stringBuilder.append(queryPurchases.getPurchasesList().size());
                    Log.i("BillingManager", stringBuilder.toString());
                    if (queryPurchases.getPurchasesList().size() > 0) {
                        for (Purchase purchase : queryPurchases.getPurchasesList()) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("getPurchasesList get sku : ");
                            stringBuilder2.append(purchase.getSku());
                            Log.i("BillingManager", stringBuilder2.toString());
                            if (purchase.getSku().equals(BillingConstants.SKU_PREMIUM)) {
                                Log.i("BillingManager", "premium : true");
                                FloatingViewService.purchased = true;
                                FloatingViewService.purchase_num = 48;
                                Editor edit = FloatingViewService.settings.edit();
                                edit.putBoolean("purchased", true);
                                edit.apply();
                            }
                        }
                    }
                    StringBuilder stringBuilder3;
                    if (BillingManager.this.areSubscriptionsSupported()) {
                        PurchasesResult queryPurchases2 = BillingManager.this.mBillingClient.queryPurchases("subs");
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append("Querying purchases and subscriptions elapsed time: ");
                        stringBuilder4.append(System.currentTimeMillis() - currentTimeMillis);
                        stringBuilder4.append("ms");
                        Log.i("BillingManager", stringBuilder4.toString());
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("Querying subscriptions result code: ");
                        stringBuilder3.append(queryPurchases2.getResponseCode());
                        stringBuilder3.append(" res: ");
                        stringBuilder3.append(queryPurchases2.getPurchasesList().size());
                        Log.i("BillingManager", stringBuilder3.toString());
                        if (queryPurchases2.getResponseCode() == 0) {
                            queryPurchases.getPurchasesList().addAll(queryPurchases2.getPurchasesList());
                        } else {
                            Log.e("BillingManager", "Got an error response trying to query subscription purchases");
                        }
                    } else if (queryPurchases.getResponseCode() == 0) {
                        Log.i("BillingManager", "Skipped subscription purchases query since they are not supported");
                    } else {
                        stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("queryPurchases() got an error response code: ");
                        stringBuilder3.append(queryPurchases.getResponseCode());
                        Log.w("BillingManager", stringBuilder3.toString());
                    }
                    BillingManager.this.onQueryPurchasesFinished(queryPurchases);
                }
            }
        });
    }

    public void startServiceConnection(final Runnable runnable) {
        if (this.mBillingClient != null) {
            this.mBillingClient.startConnection(new BillingClientStateListener() {
                public void onBillingSetupFinished(int i) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Setup finished. Response code: ");
                    stringBuilder.append(i);
                    Log.d("BillingManager", stringBuilder.toString());
                    if (i == 0) {
                        BillingManager.this.mIsServiceConnected = true;
                        if (runnable != null) {
                            runnable.run();
                        }
                    }
                    BillingManager.this.mBillingClientResponseCode = i;
                }

                public void onBillingServiceDisconnected() {
                    BillingManager.this.mIsServiceConnected = false;
                }
            });
        }
    }

    private void executeServiceRequest(Runnable runnable) {
        if (this.mIsServiceConnected) {
            runnable.run();
        } else {
            startServiceConnection(runnable);
        }
    }

    private boolean verifyValidSignature(String str, String str2) {
        if (BASE_64_ENCODED_PUBLIC_KEY.contains(BASE_64_ENCODED_PUBLIC_KEY)) {
            throw new RuntimeException("Please update your app's public key at: BASE_64_ENCODED_PUBLIC_KEY");
        }
        try {
            return Security.verifyPurchase(BASE_64_ENCODED_PUBLIC_KEY, str, str2);
        } catch (IOException e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Got an exception trying to validate a purchase: ");
            stringBuilder.append(e);
            Log.e("BillingManager", stringBuilder.toString());
            return false;
        }
    }
}
