package com.autoclicker.autoswiper.billing;

import java.util.Arrays;
import java.util.List;

public final class BillingConstants {
    private static final String[] IN_APP_SKUS = new String[]{SKU_GAS, SKU_PREMIUM};
    public static final String SKU_GAS = "gas";
    public static final String SKU_GOLD_MONTHLY = "gold_monthly";
    public static final String SKU_GOLD_YEARLY = "gold_yearly";
    public static final String SKU_PREMIUM = "premium";
    private static final String[] SUBSCRIPTIONS_SKUS = new String[]{SKU_GOLD_MONTHLY, SKU_GOLD_YEARLY};

    private BillingConstants() {
    }

    public static final List<String> getSkuList(String str) {
        if (str == "inapp") {
            return Arrays.asList(IN_APP_SKUS);
        }
        return Arrays.asList(SUBSCRIPTIONS_SKUS);
    }
}
