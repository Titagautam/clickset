package com.autoclicker.autoswiper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.MeasureSpec;

public class ViewPointerAutoSwipe extends View {
    public static boolean draw_flag = false;
    public static int pointerSize = 15;
    public Paint paint = new Paint();
    int x1;
    int x2;
    int y1;
    int y2;

    public ViewPointerAutoSwipe(Context context) {
        super(context);
        invalidate();
        this.paint.setColor(-16776961);
        this.paint.setAlpha(100);
        this.paint.setStrokeWidth(50.0f);
        this.paint.setStrokeCap(Cap.ROUND);
    }

    /* Access modifiers changed, original: protected */
    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i2);
        if (!(mode == Integer.MIN_VALUE || mode == 0 || mode != 1073741824)) {
            MeasureSpec.getSize(i2);
        }
        i2 = MeasureSpec.getMode(i);
        if (!(i2 == Integer.MIN_VALUE || i2 == 0 || i2 != 1073741824)) {
            MeasureSpec.getSize(i);
        }
        setMeasuredDimension(getContext().getApplicationContext().getResources().getDisplayMetrics().heightPixels / pointerSize, getContext().getApplicationContext().getResources().getDisplayMetrics().heightPixels / pointerSize);
    }

    public void assign(int i, int i2, int i3, int i4) {
        this.x1 = i;
        this.y1 = i2;
        this.x2 = i3;
        this.y2 = i4;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.valueOf(this.x1));
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(this.y1));
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(this.x2));
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(this.y2));
        Log.d("x1 y1 x2 y2", stringBuilder.toString());
    }

    public void onDraw(Canvas canvas) {
        Log.w("onDraw", "onDraw()");
        if (draw_flag) {
            canvas.save();
            canvas.drawLine((float) this.x1, (float) this.y1, (float) this.x2, (float) this.y2, this.paint);
            canvas.restore();
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return super.onKeyDown(i, keyEvent);
    }

    public void setPaint_Play() {
        this.paint.setColor(-16711936);
        this.paint.setAlpha(100);
        this.paint.setStrokeWidth(50.0f);
        this.paint.setStrokeCap(Cap.ROUND);
    }

    public void setPaint_Not_Play() {
        this.paint.setColor(-16776961);
        this.paint.setAlpha(100);
        this.paint.setStrokeWidth(50.0f);
        this.paint.setStrokeCap(Cap.ROUND);
    }
}
